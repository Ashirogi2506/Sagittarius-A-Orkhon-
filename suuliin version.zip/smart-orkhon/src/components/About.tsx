"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Bell, Bot, Building2, Map as MapIcon, Megaphone, Users } from "lucide-react";
import { useStore } from "@/lib/store";
import { Logo } from "./Header";
import { SectionHead } from "./ui";

const FLOW = [
  { icon: Building2, t: "Байгууллагууд", d: "Эрдэнэт Ус, цахилгаан, зам, тээврийн байгууллагууд зараа нэг стандартаар оруулна." },
  { icon: Bell, t: "Нэгдсэн мэдэгдэл", d: "Иргэн байршлаараа шүүсэн мэдэгдлийг нэг дороос хүлээн авна." },
  { icon: Megaphone, t: "Иргэдийн мэдээлэл", d: "Асуудлыг зураг, байршилтай мэдээлж, хяналтын дугаараар хянана." },
  { icon: MapIcon, t: "Газрын зураг", d: "Асуудал, тасалдал, шийдлийг газрын зураг дээр нэгтгэнэ." },
  { icon: Bot, t: "AI туслах", d: "Урт зарыг энгийнээр тайлбарлаж, асуултад эх сурвалжтай хариулна." },
  { icon: Users, t: "Хамтын шийдэл", d: "Санаа дэвшүүлж, дэмжиж, шийдлийн явцыг хамтдаа хянана." },
];

export function About() {
  return (
    <section id="about" className="mx-auto max-w-7xl px-4 py-14 md:py-20 md:px-6" aria-labelledby="about-title">
      <div className="grid gap-8 lg:grid-cols-[1fr_1.3fr] lg:items-start">
        <div>
          <SectionHead id="about-title" eyebrow="Бидний тухай" title="Орхоны мэдээлэл нэг дор"
            lead="SMART ORKHON бол «Орхон аймгийн бодит асуудлыг технологиор шийдэх» хакатонд зориулсан Sagittarius багийн MVP. Иргэд олон сайт, пэйж хуудаснаас мэдээлэл хайх шаардлагагүй болгох нь зорилго." />
          <dl className="grid grid-cols-3 gap-3">
            {[["Баг", "Sagittarius"], ["Он", "2026"], ["Төлөв", "MVP"]].map(([k, v]) => (
              <div key={k} className="glass rounded-2xl p-3"><dt className="text-xs text-muted">{k}</dt><dd className="font-display font-semibold">{v}</dd></div>
            ))}
          </dl>
        </div>
        <ol className="grid gap-x-6 gap-y-5 sm:grid-cols-2">
          {FLOW.map(({ icon: I, t, d }, i) => (
            <motion.li key={t} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }} className="flex gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-cyan/10 text-cyan"><I className="h-5 w-5" /></span>
              <span><b className="block font-semibold">{t}</b><span className="text-sm leading-relaxed text-muted">{d}</span></span>
            </motion.li>
          ))}
        </ol>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-line bg-[#040e1a]">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 md:grid-cols-[1.3fr_1fr_1fr] md:px-6">
        <div>
          <div className="flex items-center gap-2.5"><Logo /><span className="font-display font-semibold">SMART ORKHON</span></div>
          <p className="mt-3 max-w-sm text-sm text-muted">Орхон аймгийн иргэний технологийн платформын хакатоны прототип. Sagittarius баг · 2026.</p>
          <p className="mt-3 text-sm"><a href="/privacy" className="text-cyan underline">Нууцлалын бодлого</a> · <a href="/privacy#delete" className="text-cyan underline">Бүртгэл устгах</a></p>
        </div>
        <div>
          <p className="mb-3 text-sm font-semibold">Яаралтай утас</p>
          <ul className="space-y-1.5 text-sm text-muted"><li>101 · Гал унтраах, аврах</li><li>102 · Цагдаа</li><li>103 · Түргэн тусламж</li><li>105 · Онцгой байдал</li><li>11-11 · Санал, гомдол</li></ul>
        </div>
        <div>
          <p className="mb-3 text-sm font-semibold">Анхааруулга</p>
          <p className="text-sm leading-relaxed text-muted">«Жишээ мэдээлэл» гэсэн шошготой бүх зар, статистик, асуудал бодит биш. Албан ёсны мэдээллийг тухайн байгууллагын сайтаас шалгана уу. Газрын зураг © OpenStreetMap contributors.</p>
        </div>
      </div>
    </footer>
  );
}

export function Toast() {
  const { toast } = useStore();
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[60] flex justify-center px-4" role="status" aria-live="polite">
      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }} className="rounded-xl border border-cyan/30 bg-[#0b2440] px-4 py-2.5 text-sm font-semibold shadow-xl">{toast}</motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
