"use client";

import { ChevronDown, Clock, MapPin, Phone, Plane } from "lucide-react";
import { useState } from "react";
import { ARRIVAL_TIPS, CITY_FACTS, SIGHTS, SIGHT_CAT, VISITOR_CHECKED_AT, osmLink, type Sight, type SightCat } from "@/lib/data/visitor";
import { useStore } from "@/lib/store";
import { Button, SectionHead, cn } from "./ui";
import { Collapsible, useShowMore } from "./ShowMore";

export function VisitorSection() {
  const { askAI } = useStore();
  const [cat, setCat] = useState<SightCat | "all">("all");
  const list = SIGHTS.filter((s) => cat === "all" || s.cat === cat);
  const more = useShowMore(list, cat === "all" ? 6 : list.length, "Бусад үзэх газар");

  return (
    <section id="visit" className="mx-auto max-w-7xl px-4 py-14 md:py-20 md:px-6" aria-labelledby="visit-title">
      <SectionHead id="visit-title" eyebrow="Эрдэнэтэд анх удаа ирж байна уу?" title="Эрдэнэттэй танилцах"
        lead="Хотын товч танилцуулга, заавал үзэх газрууд, хэрхэн ирэх, хэрэгтэй утаснууд."
        right={<Button variant="ghost" size="sm" onClick={() => askAI("Эрдэнэтэд нэг өдөр байхад юу үзэх вэ?")}>AI-аас аяллын зөвлөгөө авах</Button>} />

      <dl className="mb-6 grid grid-cols-2 gap-2 md:grid-cols-3 xl:grid-cols-6">
        {CITY_FACTS.map((f) => (
          <div key={f.label} className="rounded-xl border border-line bg-white/[.03] p-3">
            <dt className="text-xs text-muted">{f.label}</dt>
            <dd className="mt-0.5 text-sm font-semibold leading-snug">{f.value}</dd>
          </div>
        ))}
      </dl>

      <div className="mb-4 flex flex-wrap gap-2" role="group" aria-label="Үзэх газрын төрөл">
        {(["all", ...Object.keys(SIGHT_CAT)] as (SightCat | "all")[]).map((k) => (
          <button key={k} type="button" aria-pressed={cat === k} onClick={() => setCat(k)}
            className={cn("rounded-full border px-3 py-1.5 text-[13px] transition", cat === k ? "border-cyan bg-cyan/15 text-snow" : "border-line text-muted hover:text-snow")}>
            {k === "all" ? "Бүгд" : `${SIGHT_CAT[k].icon} ${SIGHT_CAT[k].label}`}
          </button>
        ))}
      </div>

      {more.anchor}
      <ul className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {more.visible.map((s) => <SightCard key={s.id} s={s} />)}
      </ul>
      {more.button}

      <Collapsible className="mt-6" title={<><Plane className="h-5 w-5 text-cyan" />Хэрхэн ирэх, хэрэгтэй мэдээлэл</>}>
        <ul className="grid gap-3 md:grid-cols-2">
          {ARRIVAL_TIPS.map((t) => (
            <li key={t.title} className="rounded-xl border border-line p-3.5 text-sm">
              <p className="font-semibold">{t.title}</p>
              <p className="mt-1 text-muted">{t.text}</p>
              {t.href && <a href={t.href} target="_blank" rel="noopener noreferrer" className="mt-1.5 inline-flex items-center gap-1 text-xs text-cyan hover:underline"><MapPin className="h-3 w-3" />Газрын зураг дээр</a>}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm text-muted">Төрийн байгууллагын хаяг, цагийг <a href="#services" className="text-cyan underline">«Үйлчилгээ»</a>, автобусыг <a href="#bus" className="text-cyan underline">«Автобус»</a>, замын ачааллыг <a href="#map" className="text-cyan underline">«Газрын зураг»</a> хэсгээс харна.</p>
      </Collapsible>

      <p className="mt-5 text-xs text-muted">
        Эх сурвалж: <a href="https://en.wikipedia.org/wiki/Erdenet" target="_blank" rel="noopener noreferrer" className="text-cyan underline">Wikipedia</a>,{" "}
        <a href="https://www.lonelyplanet.com/mongolia/northern-mongolia/erdenet" target="_blank" rel="noopener noreferrer" className="text-cyan underline">Lonely Planet</a>,{" "}
        <a href="https://erdenet.mn/lavlah/organ" target="_blank" rel="noopener noreferrer" className="text-cyan underline">erdenet.mn</a>, байршил: © OpenStreetMap. Шалгасан: {VISITOR_CHECKED_AT}. Ажлын цаг өөрчлөгдөж болзошгүй тул очихоосоо өмнө лавлаарай.
      </p>
    </section>
  );
}

function SightCard({ s }: { s: Sight }) {
  const [open, setOpen] = useState(false);
  const hasMore = !!(s.tip || s.hours || s.phone);
  return (
    <li className="glass flex flex-col rounded-2xl p-4">
      <div className="flex items-start gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/5 text-xl" aria-hidden="true">{SIGHT_CAT[s.cat].icon}</span>
        <div className="min-w-0 flex-1">
          <h3 className="font-semibold leading-snug">{s.name}</h3>
          <p className={cn("mt-1 text-sm text-muted", !open && "line-clamp-2")}>{s.what}</p>
        </div>
      </div>
      {open && (
        <div className="mt-3 grid gap-1.5 text-sm">
          {s.tip && <p className="rounded-lg bg-cyan/[.07] px-3 py-2 text-snow/90">💡 {s.tip}</p>}
          {s.hours && <p className="flex items-center gap-2"><Clock className="h-4 w-4 text-cyan" />{s.hours}</p>}
          {s.phone && <p className="flex items-center gap-2"><Phone className="h-4 w-4 text-cyan" /><a href={"tel:" + s.phone.replace(/\D/g, "")} className="hover:text-cyan">{s.phone}</a></p>}
        </div>
      )}
      <div className="mt-auto flex flex-wrap items-center gap-x-4 gap-y-1 pt-3 text-xs">
        {(hasMore || s.what.length > 90) && (
          <button type="button" onClick={() => setOpen(!open)} aria-expanded={open} className="inline-flex items-center gap-1 font-semibold text-cyan">
            {open ? "Хураах" : "Дэлгэрэнгүй"}<ChevronDown className={cn("h-3.5 w-3.5 transition", open && "rotate-180")} />
          </button>
        )}
        {s.lat != null && s.lng != null && (
          <a href={osmLink(s.lat, s.lng)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-muted hover:text-cyan"><MapPin className="h-3 w-3" />Газрын зураг</a>
        )}
        <a href={s.source} target="_blank" rel="noopener noreferrer" className="text-muted underline hover:text-cyan">эх сурвалж</a>
      </div>
    </li>
  );
}
