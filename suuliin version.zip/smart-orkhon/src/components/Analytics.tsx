"use client";

import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useEffect, useState } from "react";
import { trafficColor, useStore } from "@/lib/store";
import { ISSUE_CAT, STATUS } from "@/lib/labels";
import type { IssueCategory, IssueStatus } from "@/lib/types";
import { SectionHead } from "./ui";

// Every number on this panel comes from the SMART ORKHON database (/api/stats). No sample data.
const axis = { stroke: "#9fb3c8", fontSize: 11, tickLine: false, axisLine: false } as const;
const tip = { contentStyle: { background: "#0d2240", border: "1px solid rgba(148,197,255,.2)", borderRadius: 12, color: "#f8fafc", fontSize: 12 }, cursor: { fill: "rgba(0,229,255,.06)" } };
const hm = (iso: string) => new Date(iso).toLocaleTimeString("mn-MN", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "Asia/Ulaanbaatar" });

function ChartCard({ title, note, empty, children, wide = false }: { title: string; note?: string; empty?: string | false; children: React.ReactNode; wide?: boolean }) {
  return (
    <figure className={`glass rounded-2xl p-5 ${wide ? "lg:col-span-2" : ""}`}>
      <figcaption className="mb-3 flex items-start justify-between gap-2 text-sm font-semibold">{title}{note && <span className="shrink-0 text-xs font-semibold text-muted">{note}</span>}</figcaption>
      <div className="h-64">{empty ? <div className="grid h-full place-items-center rounded-xl border border-dashed border-line px-6 text-center text-sm text-muted">{empty}</div> : children}</div>
    </figure>
  );
}

type View = "reports" | "traffic" | "ai";
const VIEWS: [View, string][] = [["reports", "Иргэдийн асуудал"], ["traffic", "Замын ачаалал (шууд)"], ["ai", "AI туслах"]];

export function Analytics() {
  const { stats, traffic } = useStore();
  const [view, setView] = useState<View>("reports");
  const [mounted, setMounted] = useState(false);
  // Recharts measures the DOM, so render charts after mount.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => setMounted(true), []);

  const s = stats;
  const resolvedPct = s && s.reports.total ? Math.round((s.reports.resolved / s.reports.total) * 100) : null;
  const byCat = s?.reports.byCategory.map((x) => ({ name: ISSUE_CAT[x.k as IssueCategory] ?? x.k, v: x.n })) ?? [];
  const byStatus = s?.reports.byStatus.map((x) => ({ name: STATUS[x.k as IssueStatus]?.label ?? x.k, v: x.n, c: STATUS[x.k as IssueStatus]?.color ?? "#9fb3c8" })) ?? [];
  // Live traffic (not stored): the camera centre's latest counts, refreshed every 5 minutes.
  const counted = traffic?.spots.filter((x) => x.rank >= 0 && x.vehicles != null) ?? [];
  const liveCams = [...counted].sort((a, b) => (b.vehicles ?? 0) - (a.vehicles ?? 0)).slice(0, 8)
    .map((x) => ({ name: x.name, v: x.vehicles ?? 0, c: trafficColor(x.rank) }));
  const levels = [
    { name: "Их ачаалал", v: counted.filter((x) => x.rank >= 2).length, c: trafficColor(2) },
    { name: "Дунд", v: counted.filter((x) => x.rank === 1).length, c: trafficColor(1) },
    { name: "Чөлөөтэй", v: counted.filter((x) => x.rank === 0).length, c: trafficColor(0) },
    { name: "Тооллогогүй", v: (traffic?.spots.length ?? 0) - counted.length, c: trafficColor(-1) },
  ].filter((x) => x.v > 0);
  const tiles: [string, string, string][] = s ? [
    ["Бүртгэлтэй хэрэглэгч", String(s.users), "#00e5ff"],
    ["Мэдээлсэн асуудал", String(s.reports.total), "#ff5a6e"],
    ["Шийдвэрлэсэн", resolvedPct == null ? "—" : `${resolvedPct}%`, "#00d9a5"],
    ["AI-д тавьсан асуулт", String(s.questions.total), "#ffc24b"],
    ["Тоолж буй камер (одоо)", traffic ? `${counted.length}/${traffic.spots.length}` : "—", "#a78bfa"],
    ["Ачаалалтай цэг (одоо)", traffic ? String(traffic.busy.length) : "—", "#fb923c"],
  ] : [];

  return (
    <section id="stats" className="py-14 md:py-20" aria-labelledby="stats-title">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <SectionHead id="stats-title" eyebrow="Аналитик" title="Статистик самбар"
          lead="Платформын бодит тоо: иргэдийн мэдээлсэн асуудал, AI-д тавьсан асуулт, замын ачаалал (камерын төвөөс 5 минут тутам)."
          right={s ? <span className="rounded-full border border-emerald/40 bg-emerald/10 px-3 py-1 text-xs font-semibold text-emerald">Бодит мэдээлэл · {hm(s.generatedAt)}</span> : undefined} />
        {!mounted || !s ? <div className="glass h-96 animate-pulse rounded-2xl" /> : (
          <>
            <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
              {tiles.map(([l, v, c]) => (
                <div key={l} className="glass rounded-2xl p-4"><p className="text-xs text-muted">{l}</p><p className="mt-1 font-display text-2xl font-semibold" style={{ color: c }}>{v}</p></div>
              ))}
            </div>
            <div className="mb-4 flex w-full overflow-x-auto rounded-2xl border border-line bg-white/[.03] p-1 sm:inline-flex sm:w-auto" role="tablist" aria-label="Статистикийн төрөл">
              {VIEWS.map(([k, l]) => (
                <button key={k} type="button" role="tab" aria-selected={view === k} onClick={() => setView(k)}
                  className={`shrink-0 rounded-xl px-4 py-2 text-sm font-semibold transition ${view === k ? "bg-cyan text-navy" : "text-muted hover:text-snow"}`}>{l}</button>
              ))}
            </div>
            <div className="grid gap-4 lg:grid-cols-3" role="tabpanel">
              {view === "traffic" && <>
              <ChartCard wide title="Одоогийн машины тоо, камераар (шууд)"
                note={traffic ? `${hm(traffic.fetchedAt)} · 5 мин тутам` : undefined}
                empty={!liveCams.length && (traffic ? "Камерын төв одоогоор тооллого өгөхгүй байна." : "Камерын мэдээллийг ачаалж байна…")}>
                <ResponsiveContainer><BarChart data={liveCams} layout="vertical" margin={{ left: 6 }}>
                  <XAxis type="number" hide allowDecimals={false} /><YAxis type="category" dataKey="name" {...axis} width={150} />
                  <Tooltip {...tip} formatter={(v) => [v, "Машин"]} />
                  <Bar dataKey="v" radius={[0, 8, 8, 0]}>{liveCams.map((c) => <Cell key={c.name} fill={c.c} />)}</Bar>
                </BarChart></ResponsiveContainer>
              </ChartCard>
              <ChartCard title="Замын ачааллын түвшин (одоо)" note="камерын тоо"
                empty={!levels.length && "Камерын мэдээллийг ачаалж байна…"}>
                <ResponsiveContainer><PieChart><Tooltip {...tip} formatter={(v, n) => [v, n]} />
                  <Pie data={levels} dataKey="v" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={3} stroke="none">{levels.map((c) => <Cell key={c.name} fill={c.c} />)}</Pie></PieChart></ResponsiveContainer>
              </ChartCard>
              </>}
              {view === "reports" && <>
              <ChartCard wide title="Иргэдийн мэдээлсэн асуудал, ангиллаар"
                empty={!byCat.length && "Одоогоор асуудал мэдээлэгдээгүй байна. «Асуудал мэдээлэх» хэсгээс эхний мэдээллээ илгээгээрэй."}>
                <ResponsiveContainer><BarChart data={byCat}><CartesianGrid stroke="rgba(148,197,255,.08)" vertical={false} /><XAxis dataKey="name" {...axis} /><YAxis {...axis} width={32} allowDecimals={false} />
                  <Tooltip {...tip} formatter={(v) => [v, "Асуудал"]} />
                  <Bar dataKey="v" radius={[8, 8, 0, 0]}>{byCat.map((_, i) => <Cell key={i} fill={i % 2 ? "#00d9a5" : "#00e5ff"} />)}</Bar></BarChart></ResponsiveContainer>
              </ChartCard>
              <ChartCard title="Асуудлын төлөв" empty={!byStatus.length && "Мэдээлэл ирэхэд харагдана."}>
                <ResponsiveContainer><PieChart><Tooltip {...tip} formatter={(v, n) => [v, n]} />
                  <Pie data={byStatus} dataKey="v" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={3} stroke="none">{byStatus.map((c) => <Cell key={c.name} fill={c.c} />)}</Pie></PieChart></ResponsiveContainer>
              </ChartCard>
              <ChartCard wide title="Байршлаар асуудал" empty={!s.reports.byArea.length && "Мэдээлэл ирэхэд харагдана."}>
                <ResponsiveContainer><BarChart data={s.reports.byArea} layout="vertical" margin={{ left: 6 }}><XAxis type="number" hide allowDecimals={false} /><YAxis type="category" dataKey="k" {...axis} width={100} />
                  <Tooltip {...tip} formatter={(v) => [v, "Асуудал"]} /><Bar dataKey="n" fill="#00d9a5" radius={[0, 8, 8, 0]} /></BarChart></ResponsiveContainer>
              </ChartCard>
              </>}
              {view === "ai" && <>
              <ChartCard wide title="AI туслахад тавьсан асуулт (сүүлийн 7 хоног)"
                empty={!s.questions.byDay.length && "Орхон AI туслахад асуулт тавихад энд тоологдоно."}>
                <ResponsiveContainer><BarChart data={s.questions.byDay}><CartesianGrid stroke="rgba(148,197,255,.08)" vertical={false} /><XAxis dataKey="k" {...axis} /><YAxis {...axis} width={32} allowDecimals={false} />
                  <Tooltip {...tip} formatter={(v) => [v, "Асуулт"]} /><Bar dataKey="n" fill="#ffc24b" radius={[8, 8, 0, 0]} /></BarChart></ResponsiveContainer>
              </ChartCard>
              <figure className="glass rounded-2xl p-5">
                <figcaption className="mb-3 text-sm font-semibold">AI туслахын тойм</figcaption>
                <dl className="grid gap-3 text-sm">
                  <div className="flex justify-between border-b border-line pb-2"><dt className="text-muted">Нийт асуулт</dt><dd className="font-semibold tabular-nums">{s.questions.total}</dd></div>
                  <div className="flex justify-between border-b border-line pb-2"><dt className="text-muted">Сүүлийн 7 хоногт</dt><dd className="font-semibold tabular-nums">{s.questions.byDay.reduce((a, d) => a + d.n, 0)}</dd></div>
                  <div className="flex justify-between"><dt className="text-muted">Бүртгэлтэй хэрэглэгч</dt><dd className="font-semibold tabular-nums">{s.users}</dd></div>
                </dl>
                <p className="mt-4 text-xs text-muted">Асуултын утас, регистрийн дугаарыг хадгалахаас өмнө автоматаар нууна.</p>
              </figure>
              </>}
            </div>
            <p className="mt-4 text-xs text-muted">Эх сурвалж: SMART ORKHON-ий сан (иргэдийн мэдээлэл, AI асуулт, бүртгэл) болон Орхон аймгийн ТКХДТ-ийн камерын автомат тооллого (шууд, хадгалагдахгүй). 5 минут тутам шинэчилнэ.</p>
          </>
        )}
      </div>
    </section>
  );
}
