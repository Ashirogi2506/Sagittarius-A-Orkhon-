"use client";

import { motion } from "framer-motion";
import { Bot, Building2, CalendarClock, ChevronDown, ExternalLink, Info, MapPin, Radio, ShieldCheck } from "lucide-react";
import { useMemo, useState } from "react";
import { useStore, rankForUser } from "@/lib/store";
import { ANN_CAT, VERIFY, fmtDate } from "@/lib/labels";
import type { Announcement, AnnouncementCategory } from "@/lib/types";
import { LocationPicker } from "./LocationPicker";
import { Badge, Button, Card, Empty, SectionHead, cn } from "./ui";
import { Collapsible, useShowMore } from "./ShowMore";

function AnnouncementCard({ a, relevant }: { a: Announcement; relevant: boolean }) {
  const [open, setOpen] = useState(false);
  const { markRead, readIds, askAI } = useStore();
  const cat = ANN_CAT[a.category];
  const where = [a.location.province + " аймаг", a.location.sum + " сум", a.location.bag, a.location.area].filter(Boolean).join(", ");
  const unread = !readIds.includes(a.id);
  return (
    <motion.article id={`ann-${a.id}`} layout initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-40px" }}
      className={cn("glass glass-hover relative overflow-hidden rounded-2xl p-5", relevant && "ring-1 ring-cyan/30")}>
      <span className="absolute inset-y-0 left-0 w-1" style={{ background: cat.color, boxShadow: `0 0 18px ${cat.color}` }} aria-hidden />
      <div className="mb-3 flex flex-wrap items-center gap-1.5">
        <Badge color={cat.color}>{cat.label}</Badge>
        <Badge className={VERIFY[a.verification].cls}>{a.verification === "verified-note" && <ShieldCheck className="h-3 w-3" />}{VERIFY[a.verification].label}</Badge>
        {relevant && <Badge className="border-cyan/40 bg-cyan/10 text-cyan">Таны байршил</Badge>}
        {unread && <span className="ml-auto h-2 w-2 rounded-full bg-cyan shadow-[0_0_8px_#00e5ff]" aria-label="Уншаагүй" />}
      </div>
      <p className="flex items-center gap-1.5 text-xs text-muted"><Building2 className="h-3.5 w-3.5" />{a.organization}</p>
      <h3 className="mt-1 text-[17px] font-semibold leading-snug">{a.title}</h3>
      <div className="mt-3 rounded-xl border border-emerald/25 bg-emerald/[.07] p-3">
        <p className="mb-0.5 text-[12.5px] font-bold uppercase tracking-wider text-emerald">Товчхондоо</p>
        <p className="text-sm leading-relaxed">{a.summary}</p>
      </div>
      <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
        <div className="flex gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-cyan" /><div><dt className="text-[12.5px] text-muted">Байршил</dt><dd>{where}{a.locationNote && <span className="text-warn"> · {a.locationNote}</span>}</dd></div></div>
        <div className="flex gap-2"><CalendarClock className="mt-0.5 h-4 w-4 shrink-0 text-cyan" /><div><dt className="text-[12.5px] text-muted">Эхлэх – Дуусах</dt><dd>{a.start ? fmtDate(a.start, true) : "Тодорхойгүй"} – {a.end ? fmtDate(a.end, true) : "Тодорхойгүй"}</dd></div></div>
      </dl>
      {open && (
        <div className="mt-3 border-t border-line pt-3 text-sm leading-relaxed text-muted">
          <p className="mb-1 text-[12.5px] font-bold uppercase tracking-wider text-snow/80">Дэлгэрэнгүй</p>
          <p>{a.description}</p>
          <p className="mt-3 text-xs">Нийтэлсэн: {fmtDate(a.publishedAt)} · Шалгасан: {fmtDate(a.checkedAt, true)}</p>
        </div>
      )}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <Button size="sm" variant="ghost" onClick={() => { setOpen((o) => !o); markRead(a.id); }} aria-expanded={open}>
          <ChevronDown className={cn("h-3.5 w-3.5 transition", open && "rotate-180")} />{open ? "Хураах" : "Дэлгэрэнгүй"}
        </Button>
        <a href={a.sourceUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-semibold text-cyan hover:bg-cyan/10" onClick={() => markRead(a.id)}>
          <ExternalLink className="h-3.5 w-3.5" />{a.sourceName}
        </a>
        <button type="button" onClick={() => askAI(`"${a.title}" гэсэн мэдэгдлийг энгийнээр тайлбарлаж өгөөч.`)} className="ml-auto inline-flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-semibold text-muted hover:bg-white/5 hover:text-snow">
          <Bot className="h-3.5 w-3.5" />AI тайлбар
        </button>
      </div>
    </motion.article>
  );
}

const FILTERS: ("all" | AnnouncementCategory)[] = ["all", "traffic", "water", "electricity", "road", "transport", "waste", "environment", "service", "emergency"];

export function Announcements() {
  const { announcements, prefs, ready, loadError, sources, sourcesNote, traffic } = useStore();
  const [cat, setCat] = useState<(typeof FILTERS)[number]>("all");
  const [onlyMine, setOnlyMine] = useState(false);
  const ranked = useMemo(() => rankForUser(announcements, prefs), [announcements, prefs]);
  const mine = (a: Announcement) => (!!prefs.area && a.location.area === prefs.area) || (!!prefs.bag && a.location.bag === prefs.bag);
  const list = ranked.filter((a) => (cat === "all" || a.category === cat) && (!onlyMine || mine(a)));
  const more = useShowMore(list, 4, "Бусад мэдэгдэл");

  return (
    <section id="notices" className="mx-auto max-w-7xl px-4 py-14 md:py-20 md:px-6" aria-labelledby="notices-title">
      <SectionHead id="notices-title" eyebrow="Ухаалаг мэдээллийн систем" title="Мэдэгдэл нэг дор"
        lead="Ус, цахилгаан, зам, тээвэр, хог, байгаль орчин, онцгой байдлын мэдэгдлийг олон сайт, хуудаснаас хайлгүйгээр нэг дороос харна." />

      <div className="mb-5 flex items-start gap-3 rounded-2xl border border-warn/30 bg-warn/[.07] p-4 text-sm">
        <Info className="mt-0.5 h-5 w-5 shrink-0 text-warn" />
        <p className="text-snow/90"><b>Анхааруулга:</b> {sourcesNote || "Албан ёсны байгууллагатай шууд холболт одоогоор байхгүй."} «Жишээ мэдээлэл» гэсэн шошготой зар бодит биш. Мэдэгдэл харагдахгүй байгаа нь тасалдал гараагүй гэсэн үг биш.</p>
      </div>

      {prefs.topics.traffic && (
        <div className="mb-5 flex flex-wrap items-center gap-x-4 gap-y-2 rounded-2xl border border-cyan/30 bg-cyan/[.06] p-4 text-sm" aria-live="polite">
          <span className="flex items-center gap-2 font-semibold"><span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan opacity-60" /><span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-cyan" /></span>Замын ачаалал (шууд)</span>
          <span className="text-snow/90">
            {!traffic ? "Шалгаж байна…" : !traffic.ok ? "Камерын төвөөс мэдээлэл татаж чадсангүй. 5 минутын дараа дахин оролдоно."
              : traffic.busy.length ? `Ачаалалтай: ${traffic.busy.map((b) => `${b.name} (${b.levelLabel.toLowerCase()}, ${b.vehicles} машин)`).join(", ")}`
              : `${traffic.cameras} камерын аль нь ч түгжрэлгүй.`}
          </span>
          {traffic?.ok && <span className="text-xs text-muted">{new Date(traffic.fetchedAt).toLocaleTimeString("mn-MN", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "Asia/Ulaanbaatar" })}-ийн байдлаар · 5 минут тутам шинэчилнэ</span>}
          <a href="https://dedtuv.erdenet.mn/live" target="_blank" rel="noopener noreferrer" className="ml-auto text-xs font-semibold text-cyan hover:underline">Шууд камер ↗</a>
        </div>
      )}

      <Card className="mb-6 p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm font-semibold">Миний байршил: таны бүсийн мэдэгдэл эхэнд харагдана</p>
          <label className="flex cursor-pointer items-center gap-2 text-sm text-muted"><input type="checkbox" className="h-4 w-4 accent-[#00e5ff]" checked={onlyMine} onChange={(e) => setOnlyMine(e.target.checked)} />Зөвхөн миний бүс</label>
        </div>
        <LocationPicker compact />
      </Card>

      <div className="mb-6 flex gap-2 overflow-x-auto pb-1" role="group" aria-label="Ангиллаар шүүх">
        {FILTERS.map((f) => (
          <button key={f} type="button" aria-pressed={cat === f} onClick={() => setCat(f)}
            className={cn("shrink-0 rounded-full border px-3.5 py-1.5 text-sm font-semibold transition",
              cat === f ? "border-cyan bg-cyan/15 text-cyan" : "border-line text-muted hover:border-cyan/40 hover:text-snow")}>
            {f === "all" ? "Бүгд" : ANN_CAT[f].label}
          </button>
        ))}
      </div>

      {loadError ? <Empty title="Алдаа гарлаа" text={loadError} /> : !ready || !announcements.length ? (
        <div className="grid gap-4 md:grid-cols-2">{[0, 1, 2, 3].map((i) => <div key={i} className="glass h-64 animate-pulse rounded-2xl" />)}</div>
      ) : list.length ? (
        <>{more.anchor}<div className="grid gap-4 md:grid-cols-2">{more.visible.map((a) => <AnnouncementCard key={a.id} a={a} relevant={mine(a)} />)}</div>{more.button}</>
      ) : (
        <Empty title="Энэ шүүлтүүрт мэдэгдэл алга" text="Өөр ангилал эсвэл байршил сонгоно уу." />
      )}

      <Collapsible className="mt-10" title={<><Radio className="h-5 w-5 text-cyan" />Мэдээллийн эх сурвалж, холболт</>}>
        <div className="grid gap-3 md:grid-cols-3">
          {sources.map((s) => (
            <div key={s.id} className="rounded-xl border border-line p-3.5">
              <p className="text-sm font-semibold">{s.name}</p>
              <p className="mt-1 text-xs text-muted">Төрөл: {s.kind === "admin" ? "Админ оруулсан" : s.kind === "demo" ? "Жишээ адаптер" : s.kind}</p>
              <p className="text-xs text-muted">Сүүлд шинэчилсэн: {fmtDate(s.lastUpdated, true)}</p>
              <Badge className={cn("mt-2", s.live ? "border-emerald/40 bg-emerald/10 text-emerald" : "border-line text-muted")}>{s.live ? "Шууд холбогдсон" : "Шууд холболтгүй"}</Badge>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs leading-relaxed text-muted">Цаашид албан ёсны API, RSS, зөвшөөрөгдсөн өгөгдлийн урсгал, админы оруулга, зөвшөөрөлтэй вэб уншилтаар холбогдох бүтэцтэй (src/lib/integrations). Бодит холболт хийгдсэн үед л «Шууд холбогдсон» гэж харуулна.</p>
      </Collapsible>
    </section>
  );
}
