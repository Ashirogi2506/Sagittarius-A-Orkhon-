import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { clientKey } from "@/lib/server/guard";

// Per-IP rate limits and CORS for every /api route.
// Limits are kept in memory, like guard.ts: each server instance counts on its own, so on Vercel the
// numbers are approximate. Use a shared store (e.g. Redis) when exact limits are needed.

type Limit = { name: string; limit: number; windowMs: number };

const API_LIMIT: Limit = { name: "api", limit: 100, windowMs: 5 * 60_000 };
const CHAT_LIMIT: Limit = { name: "chat", limit: 20, windowMs: 60_000 };

const hits = new Map<string, number[]>();

type Check = { rule: Limit; key: string; list: number[]; ok: boolean; remaining: number; resetSec: number };

function check(rule: Limit, ip: string, now: number): Check {
  const key = `${rule.name}:${ip}`;
  const list = (hits.get(key) || []).filter((t) => now - t < rule.windowMs);
  const ok = list.length < rule.limit;
  // Seconds until the oldest counted request leaves the window (a full window when nothing is counted yet).
  const resetSec = list.length ? Math.max(1, Math.ceil((rule.windowMs - (now - list[0])) / 1000)) : Math.ceil(rule.windowMs / 1000);
  return { rule, key, list, ok, remaining: Math.max(0, rule.limit - list.length - (ok ? 1 : 0)), resetSec };
}

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://smart-orkhon.vercel.app";

function trustedOrigins(): Set<string> {
  const list = [SITE_URL, ...(process.env.ALLOWED_ORIGINS ?? "").split(",")]
    .map((o) => o.trim().replace(/\/+$/, ""))
    .filter(Boolean);
  return new Set(list);
}
const TRUSTED = trustedOrigins();

function isSameSite(origin: string, req: NextRequest): boolean {
  try { return new URL(origin).host === (req.headers.get("x-forwarded-host") || req.headers.get("host")); } catch { return false; }
}

const CORS_METHODS = "GET, POST, PATCH, DELETE, OPTIONS";
const CORS_HEADERS = "Content-Type";

function corsHeaders(origin: string): Record<string, string> {
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Methods": CORS_METHODS,
    "Access-Control-Allow-Headers": CORS_HEADERS,
  };
}

export function proxy(req: NextRequest) {
  const origin = req.headers.get("origin");
  // No Origin header: same-origin GET, server-to-server or curl. Not a CORS request.
  const crossOrigin = !!origin && !isSameSite(origin, req);
  const allowed = !crossOrigin || TRUSTED.has(origin!);
  const cors = crossOrigin && allowed ? corsHeaders(origin!) : {};

  if (!allowed) {
    return NextResponse.json({ error: "CORS_ORIGIN_NOT_ALLOWED" }, { status: 403, headers: { Vary: "Origin" } });
  }

  if (req.method === "OPTIONS") {
    // Preflight: answered here, never reaches the route, and not counted against the rate limit.
    return new NextResponse(null, { status: 204, headers: { ...cors, "Access-Control-Max-Age": "600", Vary: "Origin" } });
  }

  const ip = clientKey(req);
  const now = Date.now();
  const path = req.nextUrl.pathname;
  const rules = path === "/api/chat" || path.startsWith("/api/chat/") ? [API_LIMIT, CHAT_LIMIT] : [API_LIMIT];
  const checks = rules.map((r) => check(r, ip, now));
  const blocked = checks.filter((c) => !c.ok);

  // The headers describe the tightest limit: the blocked one, or else the one with the fewest requests left.
  const shown = blocked.length
    ? blocked.reduce((a, b) => (b.resetSec > a.resetSec ? b : a))
    : checks.reduce((a, b) => (b.remaining < a.remaining ? b : a));
  const rlHeaders: Record<string, string> = {
    "RateLimit-Limit": String(shown.rule.limit),
    "RateLimit-Remaining": String(shown.remaining),
    "RateLimit-Reset": String(shown.resetSec),
    "RateLimit-Policy": checks.map((c) => `${c.rule.limit};w=${c.rule.windowMs / 1000}`).join(", "),
  };

  if (blocked.length) {
    return NextResponse.json(
      { error: "RATE_LIMIT_EXCEEDED", message: `Хэт олон хүсэлт илгээлээ. ${shown.resetSec} секундын дараа дахин оролдоно уу.` },
      { status: 429, headers: { ...cors, ...rlHeaders, "Retry-After": String(shown.resetSec), Vary: "Origin" } },
    );
  }

  // Count the request only when every limit allows it, so a blocked chat call does not use up the /api budget.
  for (const c of checks) { c.list.push(now); hits.set(c.key, c.list); }
  if (hits.size > 10_000) hits.clear();

  const res = NextResponse.next();
  for (const [k, v] of Object.entries({ ...cors, ...rlHeaders })) res.headers.set(k, v);
  res.headers.append("Vary", "Origin");
  return res;
}

export const config = {
  matcher: "/api/:path*",
};
