# SMART ORKHON — complete source package

This package contains the frontend, backend API routes, map and camera data,
public assets, Android publishing instructions, deployment configuration,
package.json and package-lock.json. Dependencies are restored with npm ci.

## Run locally (Windows, macOS or Linux)

1. Install Node.js 20.9 or later (Node.js 24 was used for this package).
2. Extract the ZIP, then open a terminal in the SMART_ORKHON folder.
3. Run `npm ci`.
4. Copy `.env.example` to `.env.local`. For a local preview, the values can stay empty.
5. Run `npm run dev`, then open http://localhost:3000.

Local mode creates a SQLite database in `data/`. Without a Gemini key, the chatbot
uses prepared replies; traffic replies still use the camera feed when available.

## Deploy to Vercel

Follow `DEPLOY.md`, which is included from the repository. The two supported
routes are GitHub import in Vercel or Vercel CLI from this extracted folder.

1. Use your own Vercel account and select the intended project.
2. Provision a Turso database, or use the database already connected to that project.
3. Configure `TURSO_DATABASE_URL` and `TURSO_AUTH_TOKEN` in Vercel.
   Production accounts, sessions, reports and notices need this persistent database.
   The local SQLite fallback is for local use.
4. Configure `GEMINI_API_KEY` for AI replies if desired. `GEMINI_MODEL` is optional.
5. Set `ADMIN_EMAILS` to the intended administrators. Set `NEXT_PUBLIC_SITE_URL`
   to the actual deployment address, and `NEXT_PUBLIC_CONTACT_EMAIL` for privacy contact.
6. Run `npx vercel login` and then `npx vercel deploy --prod`.
   For an existing site, verify the account and project before confirming deployment.
7. After changing environment variables, redeploy. Keep existing production values
   unless a change is specifically intended. Never put secret values in this ZIP or Git.

The package contains no account credentials or production database contents.
The application initializes its schema on first database use. Review
`src/lib/server/db.ts` before connecting an existing database: its initialization
removes the legacy `chat_logs` table and the old questions counter.

## Current functionality

For the current interface, use `README.md` and `HANDOFF.md`. Some older sections
of `DEPLOY.md` still describe removed bus, garbage and statistics interfaces.

Camera load and colored road overlays are included. Traffic-aware A-to-B routing
and turn-by-turn navigation are not implemented in this repository version.

## Package contents and provenance

- Source repository: https://github.com/Ashirogi2506/Sagittarius-A-Orkhon-
- Source commit: 540fceb1fa7abc1cbef5636e71816a8dd5dea73f
- Packaging change: use Next.js Link for the news detail page back navigation,
  resolving the existing ESLint error without changing its destination.
- `RELEASE_MANIFEST.json` records each included source file and its SHA-256.
- Nested old ZIPs, Git internals, node_modules, build output, local databases,
  account tokens and private environment files are excluded.
- `.env.example` is included as the configuration template.

## Verification

Run `npm run build` and `npm run lint -- src` to check this package.
Production publication must be confirmed by Vercel; a successful local build
alone is not a deployment.
