"use client";

import { ArrowDownUp, Baby, Bus, Clock, Plus, Search, Trash2, User } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { stopIndex, type BusRoute } from "@/lib/civic";
import { useStore } from "@/lib/store";
import { fmtDate } from "@/lib/labels";
import { Badge, Button, Card, Empty, Field, SectionHead, cn, inputCls } from "./ui";

const tg = (n: number | null) => (n == null ? "—" : `${n.toLocaleString("mn-MN")}₮`);

export function BusSection() {
  const { me, showToast, askAI } = useStore();
  const [items, setItems] = useState<BusRoute[] | null>(null);
  const [error, setError] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const admin = me?.user?.role === "admin";

  useEffect(() => {
    fetch("/api/bus").then((r) => r.json()).then((d) => setItems(d.items)).catch(() => setError("Чиглэлийг ачаалж чадсангүй."));
  }, []);

  // A route matches when it passes "from" and then "to" (either direction, since buses return the same way).
  const matches = useMemo(() => (items ?? []).map((r) => {
    const a = stopIndex(r.stops, from), b = stopIndex(r.stops, to);
    const ok = (!from.trim() || a >= 0) && (!to.trim() || b >= 0) && (a < 0 || b < 0 || a !== b);
    return { r, ok, a, b };
  }).filter((x) => x.ok), [items, from, to]);
  const allStops = useMemo(() => [...new Set((items ?? []).flatMap((r) => r.stops))].sort((x, y) => x.localeCompare(y, "mn")), [items]);

  return (
    <section id="bus" className="mx-auto max-w-7xl px-4 py-20 md:px-6" aria-labelledby="bus-title">
      <SectionHead id="bus-title" eyebrow="Нийтийн тээвэр" title="Эрдэнэтийн автобус"
        lead="Хаанаас суугаад хаана хүрэх, ямар автобус явах, том хүн, хүүхдийн үнэ хэд вэ гэдгийг нэг дороос. Мэдээллийг зөвхөн албан ёсны эх сурвалжаас админ оруулна." />
      <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
        <div className="grid gap-4">
          <Card className="p-4">
            <div className="grid items-end gap-2 sm:grid-cols-[1fr_auto_1fr]">
              <Field label="Хаанаас суух" htmlFor="b-from"><input id="b-from" list="bus-stops" className={inputCls} value={from} onChange={(e) => setFrom(e.target.value)} placeholder="Зогсоолын нэр" /></Field>
              <button type="button" onClick={() => { setFrom(to); setTo(from); }} className="mx-auto mb-1 grid h-10 w-10 place-items-center rounded-xl border border-line text-muted hover:text-snow" aria-label="Чиглэлийг солих"><ArrowDownUp className="h-4 w-4 sm:rotate-90" /></button>
              <Field label="Хаашаа явах" htmlFor="b-to"><input id="b-to" list="bus-stops" className={inputCls} value={to} onChange={(e) => setTo(e.target.value)} placeholder="Зогсоолын нэр" /></Field>
              <datalist id="bus-stops">{allStops.map((s) => <option key={s} value={s} />)}</datalist>
            </div>
          </Card>
          {error ? <p className="text-sm text-alert">{error}</p> : items === null ? <div className="h-40 animate-pulse rounded-2xl bg-white/5" /> : !items.length ? (
            <Card className="p-5">
              <Empty title="Автобусны чиглэл хараахан оруулаагүй"
                text="Эрдэнэт хотын автобусны чиглэл, зогсоол, үнийн албан ёсны мэдээлэл интернэтэд нэгдсэн байдлаар нийтлэгдээгүй байна. Нийтийн тээврийн байгууллагаас баталгаажсан хуваарь авмагц энд оруулна. Буруу мэдээлэл өгөхгүйн тулд таамаглаж бичихгүй."
                action={<Button variant="ghost" size="sm" onClick={() => askAI("Эрдэнэтэд автобусны чиглэлийн мэдээлэл хаанаас авах вэ?")}>AI-аас асуух</Button>} />
            </Card>
          ) : !matches.length ? (
            <Card className="p-5"><Empty title="Тохирох чиглэл олдсонгүй" text="Зогсоолын нэрийг өөрөөр бичиж үзнэ үү, эсвэл нэг талбарыг хоосон орхино уу." /></Card>
          ) : (
            <ul className="grid gap-3 md:grid-cols-2">
              {matches.map(({ r, a, b }) => <RouteCard key={r.id} r={r} hiA={a} hiB={b} admin={admin}
                onDelete={async () => {
                  if (!window.confirm(`№${r.number} чиглэлийг устгах уу?`)) return;
                  const res = await fetch(`/api/bus?id=${r.id}`, { method: "DELETE" }); const d = await res.json();
                  if (res.ok) { setItems(d.items); showToast("Устгалаа"); } else showToast(d.error);
                }} />)}
            </ul>
          )}
        </div>
        {admin ? <BusForm onSaved={(it) => { setItems(it); showToast("Чиглэл нэмэгдлээ"); }} /> : (
          <Card className="p-5 text-sm text-muted">
            <h3 className="mb-2 flex items-center gap-2 font-semibold text-snow"><Bus className="h-4 w-4 text-cyan" />Хэрхэн ашиглах вэ?</h3>
            <ol className="list-decimal space-y-1.5 pl-5">
              <li><b className="text-snow">Хаанаас</b> болон <b className="text-snow">хаашаа</b> гэдгээ бичнэ.</li>
              <li>Тэр хоёр зогсоолоор дайрдаг автобусууд гарна. Таны суух, буух зогсоол тодоор харагдана.</li>
              <li>Эхний, сүүлийн автобусны цаг, хэдэн минут тутам явах, том хүн, хүүхдийн үнийг шалгана.</li>
            </ol>
            <p className="mt-3">Орхон AI туслахаас «3-р микроос төв рүү ямар автобус явах вэ?» гэж асууж болно.</p>
          </Card>
        )}
      </div>
    </section>
  );
}

function RouteCard({ r, hiA, hiB, admin, onDelete }: { r: BusRoute; hiA: number; hiB: number; admin: boolean; onDelete: () => void }) {
  const [lo, hi] = hiA >= 0 && hiB >= 0 ? [Math.min(hiA, hiB), Math.max(hiA, hiB)] : [-1, -1];
  return (
    <li className="glass rounded-2xl p-4">
      <div className="flex items-start gap-3">
        <span className="grid h-12 min-w-12 shrink-0 place-items-center rounded-xl bg-cyan px-2 font-display text-xl font-extrabold text-navy">{r.number}</span>
        <div className="min-w-0 flex-1">
          <p className="font-semibold leading-snug">{r.name || `${r.stops[0]} — ${r.stops[r.stops.length - 1]}`}</p>
          <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[13px] text-muted">
            <Clock className="h-3.5 w-3.5" />{r.firstTime ?? "?"}–{r.lastTime ?? "?"}{r.intervalMin ? ` · ${r.intervalMin} мин тутам` : ""}
          </p>
        </div>
        {admin && <button type="button" onClick={onDelete} className="grid h-8 w-8 place-items-center rounded-lg text-muted hover:bg-white/10 hover:text-alert" aria-label="Устгах"><Trash2 className="h-4 w-4" /></button>}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <div className="flex items-center gap-2 rounded-xl border border-line p-2.5"><User className="h-4 w-4 text-cyan" /><div><p className="text-xs text-muted">Том хүн</p><p className="font-semibold tabular-nums">{tg(r.fareAdult)}</p></div></div>
        <div className="flex items-center gap-2 rounded-xl border border-line p-2.5"><Baby className="h-4 w-4 text-emerald" /><div><p className="text-xs text-muted">Хүүхэд</p><p className="font-semibold tabular-nums">{tg(r.fareChild)}</p></div></div>
      </div>
      {r.fareNote && <p className="mt-2 text-[13px] text-muted">{r.fareNote}</p>}
      <ol className="mt-3 space-y-0.5 border-l-2 border-line pl-3 text-sm">
        {r.stops.map((s, i) => (
          <li key={i} className={cn("relative", i >= lo && i <= hi && lo >= 0 ? "text-snow" : "text-muted", (i === hiA || i === hiB) && "font-bold text-cyan")}>
            <span className={cn("absolute -left-[17px] top-[9px] h-2 w-2 rounded-full", i === hiA || i === hiB ? "bg-cyan" : "bg-line")} />
            {s}{i === hiA && <Badge className="ml-2 border-cyan/40 bg-cyan/10 text-cyan">Суух</Badge>}{i === hiB && <Badge className="ml-2 border-emerald/40 bg-emerald/10 text-emerald">Буух</Badge>}
          </li>
        ))}
      </ol>
      <p className="mt-3 text-xs text-muted">Шинэчилсэн {fmtDate(r.updatedAt)}{r.source && <> · Эх сурвалж: {/^https?:\/\//.test(r.source) ? <a href={r.source} target="_blank" rel="noopener noreferrer" className="text-cyan underline">{r.source.replace(/^https?:\/\//, "").slice(0, 40)}</a> : r.source}</>}</p>
    </li>
  );
}

function BusForm({ onSaved }: { onSaved: (items: BusRoute[]) => void }) {
  const [f, setF] = useState({ number: "", name: "", stops: "", firstTime: "", lastTime: "", intervalMin: "", fareAdult: "", fareChild: "", fareNote: "", source: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const num = (v: string) => (v.trim() === "" ? null : Number(v));

  async function save(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    if (!f.number.trim() || f.stops.split("\n").filter((s) => s.trim()).length < 2) { setErr("Дугаар, дор хаяж 2 зогсоол оруулна уу."); return; }
    setBusy(true);
    try {
      const r = await fetch("/api/bus", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...f, intervalMin: num(f.intervalMin), fareAdult: num(f.fareAdult), fareChild: num(f.fareChild) }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      onSaved(d.items); setF({ ...f, number: "", name: "", stops: "" });
    } catch (ex) { setErr(ex instanceof Error ? ex.message : "Хадгалж чадсангүй."); } finally { setBusy(false); }
  }

  return (
    <Card className="p-5">
      <h3 className="mb-3 flex items-center gap-2 font-semibold"><Plus className="h-4 w-4 text-cyan" />Чиглэл нэмэх (админ)</h3>
      <form onSubmit={save} className="grid gap-3">
        <div className="grid grid-cols-[90px_1fr] gap-2">
          <Field label="Дугаар" htmlFor="r-num"><input id="r-num" className={inputCls} value={f.number} maxLength={12} onChange={set("number")} placeholder="1" /></Field>
          <Field label="Нэр (заавал биш)" htmlFor="r-name"><input id="r-name" className={inputCls} value={f.name} maxLength={120} onChange={set("name")} placeholder="Төв — Гэр хороолол" /></Field>
        </div>
        <Field label="Зогсоолууд (мөр бүрт нэг, дарааллаар)" htmlFor="r-stops"><textarea id="r-stops" rows={6} className={inputCls} value={f.stops} onChange={set("stops")} placeholder={"Эхний зогсоол\nДараагийн зогсоол\n…\nЭцсийн зогсоол"} /></Field>
        <div className="grid grid-cols-3 gap-2">
          <Field label="Эхний" htmlFor="r-first"><input id="r-first" type="time" className={inputCls} value={f.firstTime} onChange={set("firstTime")} /></Field>
          <Field label="Сүүлийн" htmlFor="r-last"><input id="r-last" type="time" className={inputCls} value={f.lastTime} onChange={set("lastTime")} /></Field>
          <Field label="Минут тутам" htmlFor="r-int"><input id="r-int" type="number" min={1} max={240} className={inputCls} value={f.intervalMin} onChange={set("intervalMin")} /></Field>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Том хүн (₮)" htmlFor="r-fa"><input id="r-fa" type="number" min={0} className={inputCls} value={f.fareAdult} onChange={set("fareAdult")} /></Field>
          <Field label="Хүүхэд (₮)" htmlFor="r-fc"><input id="r-fc" type="number" min={0} className={inputCls} value={f.fareChild} onChange={set("fareChild")} /></Field>
        </div>
        <Field label="Үнийн тайлбар" htmlFor="r-fn"><input id="r-fn" className={inputCls} value={f.fareNote} maxLength={200} onChange={set("fareNote")} placeholder="Жишээ: 6 хүртэлх насны хүүхэд үнэгүй" /></Field>
        <Field label="Эх сурвалж" htmlFor="r-src"><input id="r-src" className={inputCls} value={f.source} maxLength={300} onChange={set("source")} placeholder="Тээврийн байгууллага, албан бичиг, холбоос" /></Field>
        {err && <p className="text-sm text-alert" role="alert">{err}</p>}
        <Button type="submit" disabled={busy}>{busy ? "Хадгалж байна…" : "Хадгалах"}</Button>
        <p className="flex items-center gap-1.5 text-xs text-muted"><Search className="h-3.5 w-3.5" />Зогсоолын нэрийг иргэд хайхад ашиглана, тиймээс түгээмэл нэрээр нь бичнэ үү.</p>
      </form>
    </Card>
  );
}
