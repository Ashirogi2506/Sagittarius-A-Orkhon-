"use client";

import { AnimatePresence, animate, motion, useInView } from "framer-motion";
import { AlertTriangle, ArrowRight, Bell, Bot, CheckCircle2, Map as MapIcon, MapPin, Megaphone, Users, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { CityIllustration, type ZoneId } from "./CityIllustration";
import { useStore } from "@/lib/store";
import { DEMO_ISSUES } from "@/lib/data/places";
import { Badge, Button, DemoTag, buttonVariants } from "./ui";
import { WeatherChip } from "./WeatherChip";

const ZONES: Record<ZoneId, { title: string; text: string; area?: string; tags: string[]; ask: string }> = {
  mine: { title: "Эрдэнэтийн ил уурхай", text: "Зэс, молибдены ил уурхай нь хотын эдийн засгийн гол тулгуур. Тоос, ус ашиглалт, хүнд даацын тээврийн мэдээллийг энд нэгтгэх боломжтой.", tags: ["Байгаль орчин", "Аюулгүй байдал"], ask: "Байгаль орчны ямар мэдэгдэл байна?" },
  plant: { title: "Эрдэнэт үйлдвэр", text: "Баяжуулах фабрик ба үйлдвэрийн бүс. Цахилгаан, усны томоохон хэрэглэгч тул тасалдлын мэдээлэл хотод шууд нөлөөлдөг.", tags: ["Цахилгаан", "Ус"], ask: "Цахилгаан тасрах мэдэгдэл байна уу?" },
  center: { title: "Хотын төв, орон сууцны хороолол", text: "Микрүүдийн орон сууц, Соёлын төв ордон, цэцэрлэгт хүрээлэн. Ус, дулааны тасалдал хамгийн олон айлд нөлөөлдөг бүс.", area: "3-р микро", tags: ["Ус, дулаан", "Гэрэлтүүлэг"], ask: "Манай багт ус тасрах уу?" },
  ger: { title: "Гэр хороолол", text: "Агаарын бохирдол, хог тээвэр, ус түгээх байрны асуудал түлхүү гардаг бүс. Иргэдийн мэдээлэл энд хамгийн их хэрэгтэй.", area: "Гэр хороолол", tags: ["Агаар", "Хог", "Ус түгээх байр"], ask: "Манай ойролцоо ямар асуудал байна?" },
  junction: { title: "Гол зам, Барилгачин уулзвар", text: "2026.11.20-нд шалгахад Барилгачдын талбайн уулзвар түгжрэлтэй, А1001 зам ачаалал ихтэй байсан (эх сурвалж: dedtuv.erdenet.mn/live).", tags: ["Замын хөдөлгөөн", "Нийтийн тээвэр"], ask: "Замын ямар мэдээ байна?" },
  hills: { title: "Ногоон толгод, байгаль", text: "Хотыг тойрсон ой, толгод. Ой хээрийн түймэр, хог хаягдал, байгаль орчны мэдээллийг иргэд мэдээлж болно.", tags: ["Байгаль орчин"], ask: "Шийдвэрлэгдсэн асуудлуудыг харуул." },
};

function Counter({ to, label, icon: Icon, color }: { to: number; label: string; icon: typeof Users; color: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true });
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const c = animate(0, to, { duration: 1.6, ease: "easeOut", onUpdate: (x) => setV(Math.round(x)) });
    return () => c.stop();
  }, [inView, to]);
  return (
    <div ref={ref} className="glass glass-hover flex items-center gap-4 rounded-2xl p-4">
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl" style={{ background: color + "1f", color, boxShadow: `0 0 20px -6px ${color}` }}><Icon className="h-5 w-5" /></span>
      <div>
        <p className="font-display text-2xl font-semibold tabular-nums">{v.toLocaleString("mn-MN")}</p>
        <p className="text-xs text-muted">{label}</p>
      </div>
    </div>
  );
}

export function Hero() {
  const [zone, setZone] = useState<ZoneId | null>(null);
  const { askAI, prefs, setPrefs, stats } = useStore();
  const z = zone ? ZONES[zone] : null;
  const issues = z?.area ? DEMO_ISSUES.filter((i) => i.area === z.area && i.status !== "resolved").length : 0;

  return (
    <section id="home" className="bg-grid relative overflow-hidden" aria-labelledby="hero-title">
      <div className="mx-auto max-w-7xl px-4 pb-14 pt-10 md:px-6 md:pt-16">
        <div className="grid items-center gap-10 lg:grid-cols-[1fr_1.35fr]">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="mb-5 flex flex-wrap items-center gap-2">
              <Badge className="border-cyan/40 bg-cyan/10 text-cyan"><span className="h-1.5 w-1.5 rounded-full bg-cyan shadow-[0_0_8px_#00e5ff]" />Орхон аймаг · Эрдэнэт хот</Badge>
              <WeatherChip />
            </div>
            <h1 id="hero-title" className="font-display text-[2.1rem] font-extrabold leading-[1.12] md:text-5xl">
              <span className="text-gradient">Орхон аймгийн ирээдүйг</span><br />хамтдаа бүтээе.
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-muted md:text-lg">Иргэдийн оролцоо, ухаалаг технологиор асуудлыг шийдэж, хэрэгтэй мэдээллийг нэг дор хүргэнэ.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#report" className={buttonVariants({ size: "lg" })}><Megaphone className="h-5 w-5" />Асуудал мэдээлэх</a>
              <a href="#notices" className={buttonVariants({ size: "lg", variant: "ghost" })}><Bell className="h-5 w-5" />Мэдэгдэл харах</a>
              <a href="#map" className={buttonVariants({ size: "lg", variant: "ghost" })}><MapIcon className="h-5 w-5" />Газрын зураг үзэх</a>
            </div>
            <p className="mt-6 flex items-start gap-2 text-xs text-muted"><MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald" />Зураг дээрх бүсүүд дээр дарж тухайн бүсийн мэдээллийг харна уу.</p>
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, delay: 0.1 }} className="relative">
            <div className="glass overflow-hidden rounded-3xl p-1.5 shadow-[0_40px_120px_-40px_rgba(0,229,255,.35)]">
              <div className="overflow-hidden rounded-[1.25rem]">
                <CityIllustration onZone={setZone} active={zone} />
              </div>
            </div>
            <p className="mt-2 text-right text-[12.5px] text-muted">Уран сайхны дүрслэл. Газарзүйн яг байршлыг харуулахгүй.</p>

            <AnimatePresence>
              {z && (
                <motion.div key={zone} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
                  className="glass absolute bottom-10 left-3 right-3 z-10 rounded-2xl p-4 sm:left-auto sm:w-[360px]" role="dialog" aria-label={z.title}>
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-display text-base font-semibold">{z.title}</h3>
                    <button type="button" onClick={() => setZone(null)} className="grid h-7 w-7 shrink-0 place-items-center rounded-lg hover:bg-white/10" aria-label="Хаах"><X className="h-4 w-4" /></button>
                  </div>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted">{z.text}</p>
                  <div className="mt-2.5 flex flex-wrap gap-1.5">{z.tags.map((t) => <Badge key={t} className="border-line text-snow">{t}</Badge>)}</div>
                  {z.area && <p className="mt-2 text-xs text-muted">Идэвхтэй асуудал: <b className="text-snow">{issues}</b> <DemoTag>жишээ</DemoTag></p>}
                  <div className="mt-3 flex flex-wrap gap-2">
                    {z.area && <Button size="sm" variant="ghost" onClick={() => { setPrefs({ ...prefs, area: z.area! }); document.getElementById("notices")?.scrollIntoView({ behavior: "smooth" }); }}><ArrowRight className="h-3.5 w-3.5" />Энэ бүсийн мэдэгдэл</Button>}
                    <Button size="sm" onClick={() => askAI(z.ask)}><Bot className="h-3.5 w-3.5" />AI-аас асуух</Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        <div className="mt-12">
          <div className="mb-3 flex items-center gap-2"><p className="text-sm font-semibold">Платформын үзүүлэлт</p>
            <span className="rounded-full border border-emerald/40 bg-emerald/10 px-2 py-0.5 text-xs font-semibold text-emerald">Бодит тоо</span></div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Counter to={stats?.reports.total ?? 0} label="Мэдээлсэн асуудал" icon={AlertTriangle} color="#ff5a6e" />
            <Counter to={stats?.reports.resolved ?? 0} label="Шийдвэрлэгдсэн асуудал" icon={CheckCircle2} color="#00d9a5" />
            <Counter to={stats?.users ?? 0} label="Бүртгэлтэй хэрэглэгч" icon={Users} color="#00e5ff" />
            <Counter to={stats?.questions.total ?? 0} label="AI-д тавьсан асуулт" icon={Bell} color="#ffc24b" />
          </div>
        </div>
      </div>
    </section>
  );
}
