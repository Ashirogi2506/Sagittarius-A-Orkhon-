"use client";

import { Bell, Menu, X } from "lucide-react";
import { useState } from "react";
import { useStore, isRelevant } from "@/lib/store";
import { NotificationCenter } from "./NotificationCenter";
import { AccountButton } from "./Account";

// The logo already links home; "about" is in the phone menu and at the bottom of the page.
const NAV = [
  ["#alerts", "Шуурхай"], ["#notices", "Мэдэгдэл"], ["#report", "Асуудлууд"], ["#map", "Газрын зураг"],
  ["#bus", "Автобус"], ["#garbage", "Хог ачилт"], ["#solutions", "Шийдлүүд"], ["#stats", "Статистик"],
] as const;

export function Logo() {
  return (
    <svg viewBox="0 0 40 40" className="h-9 w-9" aria-hidden="true">
      <defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#00e5ff" /><stop offset="1" stopColor="#00d9a5" /></linearGradient></defs>
      <rect x="2" y="2" width="36" height="36" rx="11" fill="#0b2440" stroke="url(#lg)" strokeWidth="1.5" />
      <path d="M9 27 L15 18 L19 23 L24 13 L31 27 Z" fill="url(#lg)" opacity=".9" />
      <circle cx="24" cy="13" r="2.4" fill="#f8fafc" />
    </svg>
  );
}

export function Header() {
  const { announcements, readIds, prefs, ready } = useStore();
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const unread = ready ? announcements.filter((a) => isRelevant(a, prefs) && !readIds.includes(a.id)).length : 0;

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-navy/75 backdrop-blur-xl">
      <div className="mx-auto flex h-[68px] max-w-7xl items-center gap-4 px-4 md:px-6">
        <a href="#home" className="flex items-center gap-2.5" aria-label="SMART ORKHON нүүр">
          <Logo />
          <span className="whitespace-nowrap leading-tight">
            <span className="block font-display text-[15px] font-bold tracking-wide">SMART ORKHON</span>
            <span className="block text-[12.5px] text-muted">Ухаалаг Орхон</span>
          </span>
        </a>
        {/* 8 Mongolian labels need ~1200px on one line; below that the menu button is used so labels never wrap. */}
        <nav className="ml-auto hidden items-center gap-0.5 xl:flex" aria-label="Үндсэн цэс">
          {NAV.map(([h, l]) => (
            <a key={h} href={h} className="whitespace-nowrap rounded-lg px-2.5 py-2 text-[14.5px] font-medium text-muted transition hover:bg-white/5 hover:text-snow">{l}</a>
          ))}
        </nav>
        <button type="button" onClick={() => setOpen(true)} className="relative ml-auto grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-line bg-white/5 transition hover:border-cyan/50 xl:ml-2"
          aria-label={`Мэдэгдлийн төв${unread ? `, ${unread} уншаагүй` : ""}`}>
          <Bell className="h-[18px] w-[18px]" />
          {unread > 0 && (
            <span className="absolute -right-1.5 -top-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-alert px-1 text-[11px] font-bold text-white shadow-[0_0_12px_rgba(255,90,110,.7)]">{unread}</span>
          )}
        </button>
        <AccountButton />
        <button type="button" className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-line bg-white/5 xl:hidden" onClick={() => setMenu((m) => !m)} aria-expanded={menu} aria-label="Цэс">
          {menu ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>
      {menu && (
        <nav className="border-t border-line px-4 pb-4 pt-2 xl:hidden" aria-label="Гар утасны цэс">
          {[...NAV, ["#about", "Бидний тухай"] as const].map(([h, l]) => <a key={h} href={h} onClick={() => setMenu(false)} className="block rounded-lg px-3 py-2.5 text-[15px] text-snow hover:bg-white/5">{l}</a>)}
        </nav>
      )}
      <NotificationCenter open={open} onClose={() => setOpen(false)} />
    </header>
  );
}
