"use client";

import { CalendarClock, Plus, Trash2, Truck } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { LOCATIONS } from "@/lib/data/places";
import { useStore } from "@/lib/store";
import { fmtDate } from "@/lib/labels";
import { Badge, Button, Card, Empty, Field, SectionHead, cn, inputCls } from "./ui";

const WEEKDAYS = ["Даваа", "Мягмар", "Лхагва", "Пүрэв", "Баасан", "Бямба", "Ням"];
// JS getDay(): 0 = Sunday. Ulaanbaatar time.
const todayName = () => WEEKDAYS[(new Date(Date.now() + 8 * 3600_000).getUTCDay() + 6) % 7];

interface Entry { id: number; sum: string; bag: string | null; area: string | null; days: string[]; timeFrom: string | null; timeTo: string | null; note: string | null; source: string | null; updatedAt: string }

export function GarbageSection() {
  const { prefs, me, showToast } = useStore();
  const [items, setItems] = useState<Entry[] | null>(null);
  const [error, setError] = useState("");
  const [onlyMine, setOnlyMine] = useState(true);
  const isAdmin = me?.user?.role === "admin";

  const [today, setToday] = useState("");

  useEffect(() => {
    // "today" is computed in the browser (not at prerender time), once the schedule arrives.
    fetch("/api/garbage").then((r) => r.json()).then((d) => { setToday(todayName()); setItems(d.items); })
      .catch(() => { setToday(todayName()); setError("Хуваарийг ачаалж чадсангүй."); });
  }, []);

  const mine = (e: Entry) => e.sum === prefs.sum && (!prefs.bag || !e.bag || e.bag === prefs.bag) && (!prefs.area || !e.area || e.area === prefs.area);
  const list = useMemo(() => (items ?? []).filter((e) => !onlyMine || mine(e)), [items, onlyMine, prefs]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <section id="garbage" className="mx-auto max-w-7xl px-4 py-20 md:px-6" aria-labelledby="garbage-title">
      <SectionHead id="garbage-title" eyebrow="Хог хаягдал" title="Хог ачилтын хуваарь"
        lead="Таны баг, хорооллын хог ачих гариг, цагийг нэг дороос харна. Хуваарийг зөвхөн баталгаажсан эх сурвалжаас админ оруулна." />
      <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
        <Card className="p-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <p className="flex items-center gap-2 text-sm font-semibold"><CalendarClock className="h-4 w-4 text-cyan" />Өнөөдөр: {today || "…"}</p>
            <label className="flex cursor-pointer items-center gap-2 text-sm text-muted"><input type="checkbox" className="h-4 w-4 accent-[#00e5ff]" checked={onlyMine} onChange={(e) => setOnlyMine(e.target.checked)} />Зөвхөн миний байршил ({[prefs.sum, prefs.bag, prefs.area].filter(Boolean).join(", ")})</label>
          </div>
          {error ? <p className="text-sm text-alert">{error}</p> : items === null ? <div className="h-40 animate-pulse rounded-xl bg-white/5" /> : list.length ? (
            <ul className="grid gap-2.5">
              {list.map((e) => {
                const isToday = e.days.includes(today);
                return (
                  <li key={e.id} className={cn("flex items-start gap-3 rounded-xl border p-3.5", isToday ? "border-emerald/50 bg-emerald/[.07]" : "border-line")}>
                    <Truck className={cn("mt-0.5 h-5 w-5 shrink-0", isToday ? "text-emerald" : "text-cyan")} />
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold">{[e.bag, e.area].filter(Boolean).join(" · ")} <span className="text-xs font-normal text-muted">({e.sum})</span></p>
                      <div className="mt-1.5 flex flex-wrap gap-1.5">
                        {WEEKDAYS.map((d) => <span key={d} className={cn("rounded-md px-2 py-0.5 text-xs", e.days.includes(d) ? (d === today ? "bg-emerald text-navy font-bold" : "bg-cyan/15 text-cyan font-semibold") : "text-muted/50")}>{d.slice(0, 2)}</span>)}
                        {e.timeFrom && <span className="ml-1 text-xs text-snow">{e.timeFrom}{e.timeTo ? `–${e.timeTo}` : ""}</span>}
                      </div>
                      {e.note && <p className="mt-1.5 text-sm text-muted">{e.note}</p>}
                      <p className="mt-1 text-[12.5px] text-muted">Шинэчилсэн {fmtDate(e.updatedAt)}{e.source && <> · Эх сурвалж: {/^https?:\/\//.test(e.source) ? <a href={e.source} target="_blank" rel="noopener noreferrer" className="text-cyan underline">{e.source.replace(/^https?:\/\//, "").slice(0, 40)}</a> : e.source}</>}</p>
                    </div>
                    {isToday && <Badge className="border-emerald/40 bg-emerald/10 text-emerald">Өнөөдөр</Badge>}
                    {isAdmin && (
                      <button type="button" aria-label="Устгах" className="grid h-8 w-8 place-items-center rounded-lg text-muted hover:bg-white/10 hover:text-alert"
                        onClick={async () => { const r = await fetch(`/api/garbage?id=${e.id}`, { method: "DELETE" }); const d = await r.json(); if (r.ok) { setItems(d.items); showToast("Устгалаа"); } else showToast(d.error); }}>
                        <Trash2 className="h-4 w-4" /></button>
                    )}
                  </li>
                );
              })}
            </ul>
          ) : (
            <Empty title={items.length ? "Таны байршлын хуваарь алга" : "Албан ёсны хуваарь хараахан оруулаагүй"}
              text={items.length ? "Шүүлтүүрийг унтрааж бусад бүсийн хуваарийг харна уу, эсвэл баг, хорооныхоо ажилтнаас лавлана уу."
                : "Эрдэнэт хотын баг, хорооллын хог ачилтын хуваарь албан ёсны сайтад нэгдсэн байдлаар нийтлэгдээгүй байна. Тохижилтын байгууллага эсвэл баг, хорооноос баталгаажсан хуваарь авмагц энд оруулна."} />
          )}
        </Card>
        {isAdmin ? <AdminForm onSaved={(it) => { setItems(it); showToast("Хуваарь нэмэгдлээ"); }} /> : (
          <Card className="p-5 text-sm text-muted">
            <h3 className="mb-2 font-semibold text-snow">Хуваарийг хэн оруулах вэ?</h3>
            <p>Буруу хуваарь иргэдийг төөрөгдүүлэх тул зөвхөн <b className="text-snow">админ эрхтэй</b> хэрэглэгч баталгаажсан эх сурвалжтайгаар оруулна. Админ эрхийг серверийн <code className="text-cyan">ADMIN_EMAILS</code> тохиргоогоор олгоно.</p>
            <p className="mt-3">Хуваарь оруулсны дараа Орхон AI туслах ч «Манай байранд хог хэзээ ачих вэ?» гэсэн асуултад энэ хуваариар хариулна.</p>
          </Card>
        )}
      </div>
    </section>
  );
}

function AdminForm({ onSaved }: { onSaved: (items: Entry[]) => void }) {
  const [sum, setSum] = useState(LOCATIONS.sums[0].name);
  const [bag, setBag] = useState("");
  const [area, setArea] = useState("");
  const [days, setDays] = useState<string[]>([]);
  const [timeFrom, setFrom] = useState("");
  const [timeTo, setTo] = useState("");
  const [note, setNote] = useState("");
  const [source, setSource] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const s = LOCATIONS.sums.find((x) => x.name === sum) ?? LOCATIONS.sums[0];

  async function save(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    if ((!bag && !area) || !days.length) { setErr("Баг эсвэл хороолол, дор хаяж нэг гариг сонгоно уу."); return; }
    setBusy(true);
    try {
      const r = await fetch("/api/garbage", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sum, bag, area, days, timeFrom, timeTo, note, source }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      onSaved(d.items); setDays([]); setNote("");
    } catch (ex) { setErr(ex instanceof Error ? ex.message : "Хадгалж чадсангүй."); } finally { setBusy(false); }
  }

  return (
    <Card className="p-5">
      <h3 className="mb-3 flex items-center gap-2 font-semibold"><Plus className="h-4 w-4 text-cyan" />Хуваарь нэмэх (админ)</h3>
      <form onSubmit={save} className="grid gap-3">
        <div className="grid grid-cols-2 gap-2">
          <Field label="Сум" htmlFor="g-sum"><select id="g-sum" className={inputCls} value={sum} onChange={(e) => { setSum(e.target.value); setBag(""); setArea(""); }}>{LOCATIONS.sums.map((x) => <option key={x.name}>{x.name}</option>)}</select></Field>
          <Field label="Баг" htmlFor="g-bag"><select id="g-bag" className={inputCls} value={bag} onChange={(e) => setBag(e.target.value)}><option value="">—</option>{s.bags.map((x) => <option key={x}>{x}</option>)}</select></Field>
        </div>
        <Field label="Хороолол / микро" htmlFor="g-area"><select id="g-area" className={inputCls} value={area} onChange={(e) => setArea(e.target.value)}><option value="">—</option>{s.areas.map((x) => <option key={x}>{x}</option>)}</select></Field>
        <div>
          <p className="mb-1.5 text-sm font-semibold">Ачих гариг</p>
          <div className="flex flex-wrap gap-1.5">
            {WEEKDAYS.map((d) => (
              <button key={d} type="button" aria-pressed={days.includes(d)} onClick={() => setDays((x) => (x.includes(d) ? x.filter((y) => y !== d) : [...x, d]))}
                className={cn("rounded-lg border px-2.5 py-1 text-xs font-semibold", days.includes(d) ? "border-cyan bg-cyan/15 text-cyan" : "border-line text-muted")}>{d}</button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Эхлэх цаг" htmlFor="g-from"><input id="g-from" type="time" className={inputCls} value={timeFrom} onChange={(e) => setFrom(e.target.value)} /></Field>
          <Field label="Дуусах цаг" htmlFor="g-to"><input id="g-to" type="time" className={inputCls} value={timeTo} onChange={(e) => setTo(e.target.value)} /></Field>
        </div>
        <Field label="Тэмдэглэл" htmlFor="g-note"><input id="g-note" className={inputCls} value={note} maxLength={300} onChange={(e) => setNote(e.target.value)} placeholder="Жишээ: Хогоо 07:30-аас өмнө гаргана" /></Field>
        <Field label="Эх сурвалж (заавал зөвлөнө)" htmlFor="g-src"><input id="g-src" className={inputCls} value={source} maxLength={300} onChange={(e) => setSource(e.target.value)} placeholder="Албан бичиг, холбоос эсвэл байгууллагын нэр" /></Field>
        {err && <p className="text-sm text-alert" role="alert">{err}</p>}
        <Button type="submit" disabled={busy}>{busy ? "Хадгалж байна…" : "Хадгалах"}</Button>
      </form>
    </Card>
  );
}
