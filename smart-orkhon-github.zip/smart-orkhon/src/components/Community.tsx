"use client";

import { Lightbulb, MessageCircle, Plus, ThumbsUp } from "lucide-react";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { fmtDate } from "@/lib/labels";
import type { Solution } from "@/lib/types";
import { Badge, Button, Card, DemoTag, Field, SectionHead, cn, inputCls } from "./ui";

const PROGRESS: Record<Solution["progress"], { l: string; pct: number }> = {
  idea: { l: "Санаа", pct: 15 }, review: { l: "Хэлэлцэж байна", pct: 45 }, planned: { l: "Төлөвлөгдсөн", pct: 75 }, done: { l: "Хэрэгжсэн", pct: 100 },
};

function SolutionCard({ s }: { s: Solution }) {
  const { vote, voted, addComment } = useStore();
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const did = voted.includes(s.id);
  return (
    <Card className="glass-hover flex flex-col p-5">
      <div className="flex flex-wrap items-center gap-1.5">
        <Badge className="border-cyan/40 bg-cyan/10 text-cyan">{PROGRESS[s.progress].l}</Badge>
        {s.demo ? <DemoTag>Жишээ</DemoTag> : <Badge className="border-line text-muted">Таны санал</Badge>}
      </div>
      <p className="mt-3 text-xs text-muted">Асуудал: {s.issueTitle}</p>
      <h3 className="mt-1 font-semibold leading-snug">{s.idea}</h3>
      <p className="mt-1 text-xs text-muted">{s.author}</p>
      <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-white/10" role="progressbar" aria-valuenow={PROGRESS[s.progress].pct} aria-valuemin={0} aria-valuemax={100} aria-label="Явц">
        <div className="h-full rounded-full bg-gradient-to-r from-cyan to-emerald" style={{ width: `${PROGRESS[s.progress].pct}%` }} />
      </div>
      <div className="mt-4 flex items-center gap-2">
        <Button size="sm" variant={did ? "emerald" : "ghost"} onClick={() => vote(s.id)} disabled={did} aria-pressed={did}>
          <ThumbsUp className="h-4 w-4" />{did ? "Дэмжсэн" : "Дэмжих"} · {s.votes}
        </Button>
        <Button size="sm" variant="subtle" onClick={() => setOpen((o) => !o)} aria-expanded={open}><MessageCircle className="h-4 w-4" />{s.comments.length}</Button>
      </div>
      {open && (
        <div className="mt-3 border-t border-line pt-3">
          <ul className="space-y-2 text-sm">
            {s.comments.map((c, i) => <li key={i} className="rounded-lg bg-white/[.04] px-3 py-2"><b className="text-snow">{c.who}</b> <span className="text-xs text-muted">{fmtDate(c.at)}</span><p className="text-muted">{c.text}</p></li>)}
            {!s.comments.length && <li className="text-muted">Сэтгэгдэл алга.</li>}
          </ul>
          <form className="mt-2 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (text.trim().length > 1) { addComment(s.id, text.trim().slice(0, 240)); setText(""); } }}>
            <label htmlFor={`c-${s.id}`} className="sr-only">Сэтгэгдэл</label>
            <input id={`c-${s.id}`} className={inputCls} value={text} onChange={(e) => setText(e.target.value)} placeholder="Сэтгэгдэл бичих…" maxLength={240} />
            <Button size="sm" type="submit">Нэмэх</Button>
          </form>
        </div>
      )}
    </Card>
  );
}

export function Community() {
  const { solutions, addSolution, showToast } = useStore();
  const [issue, setIssue] = useState("");
  const [idea, setIdea] = useState("");
  const [err, setErr] = useState("");
  return (
    <section id="solutions" className="mx-auto max-w-7xl px-4 py-20 md:px-6" aria-labelledby="sol-title">
      <SectionHead id="sol-title" eyebrow="Олон нийтийн шийдэл" title="Шийдлүүд"
        lead="Асуудлыг хэрхэн шийдэх санаагаа дэвшүүлж, бусдын санааг дэмжиж, хэлэлцүүлэгт оролцоорой." />
      <p className="mb-6 text-sm text-muted">Санал өгөлт нь туршилтын горимд нэг төхөөрөмжөөс нэг удаа тоологдоно. Энэ нь албан ёсны олон нийтийн санал асуулга биш.</p>
      <div className="grid gap-5 lg:grid-cols-[360px_1fr]">
        <Card className="h-fit p-5">
          <div className="mb-4 flex items-center gap-2"><Lightbulb className="h-5 w-5 text-warn" /><h3 className="font-semibold">Шийдэл санал болгох</h3></div>
          <form className="grid gap-3" onSubmit={(e) => {
            e.preventDefault();
            if (issue.trim().length < 4 || idea.trim().length < 10) { setErr("Асуудал (4+) болон санаагаа (10+ тэмдэгт) бичнэ үү."); return; }
            setErr("");
            addSolution({ id: "U-" + Date.now(), issueTitle: issue.trim(), idea: idea.trim(), author: "Та", votes: 0, progress: "idea", comments: [], demo: false });
            setIssue(""); setIdea(""); showToast("Санаа нэмэгдлээ");
          }}>
            <Field label="Аль асуудал?" htmlFor="s-issue"><input id="s-issue" className={inputCls} value={issue} onChange={(e) => setIssue(e.target.value)} maxLength={80} placeholder="Жишээ: Гэр хорооллын гэрэлтүүлэг" /></Field>
            <Field label="Таны санаа" htmlFor="s-idea"><textarea id="s-idea" rows={4} className={inputCls} value={idea} onChange={(e) => setIdea(e.target.value)} maxLength={400} placeholder="Хэрхэн шийдэж болох вэ?" /></Field>
            {err && <p className="text-xs text-alert">{err}</p>}
            <Button type="submit"><Plus className="h-4 w-4" />Санал нэмэх</Button>
          </form>
        </Card>
        <div className={cn("grid gap-4 md:grid-cols-2")}>
          {[...solutions].sort((a, b) => b.votes - a.votes).map((s) => <SolutionCard key={s.id} s={s} />)}
        </div>
      </div>
    </section>
  );
}
