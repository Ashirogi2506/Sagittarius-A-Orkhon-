"use client";

import { AnimatePresence, motion } from "framer-motion";
import { LogIn, LogOut, MessageSquare, ShieldCheck, Trash2, User, X } from "lucide-react";
import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";
import { ISSUE_CAT, STATUS, fmtDate } from "@/lib/labels";
import type { IssueCategory, IssueStatus } from "@/lib/types";
import { Badge, Button, Field, cn, inputCls } from "./ui";

/** Header button: "Нэвтрэх" when signed out, the user's initial when signed in. */
export function AccountButton() {
  const { me } = useStore();
  const [open, setOpen] = useState(false);
  const user = me?.user;
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}
        className={cn("grid h-10 place-items-center rounded-xl border border-line bg-white/5 text-sm font-semibold transition hover:border-cyan/50", user ? "w-10 text-cyan" : "px-3")}
        aria-label={user ? `Миний бүртгэл: ${user.name}` : "Нэвтрэх эсвэл бүртгүүлэх"}>
        {user ? user.name.trim().charAt(0).toUpperCase() : <span className="flex items-center gap-1.5"><LogIn className="h-4 w-4" /><span className="hidden sm:inline">Нэвтрэх</span></span>}
      </button>
      <AnimatePresence>{open && <AccountDialog onClose={() => setOpen(false)} />}</AnimatePresence>
    </>
  );
}

function AccountDialog({ onClose }: { onClose: () => void }) {
  const { me } = useStore();
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <>
      <motion.div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} />
      <motion.div role="dialog" aria-modal="true" aria-label="Бүртгэл"
        className="fixed inset-x-3 top-20 z-50 mx-auto max-h-[calc(100dvh-6rem)] max-w-md overflow-y-auto rounded-3xl border border-cyan/30 bg-[#071a2e]/95 p-5 shadow-2xl backdrop-blur-xl"
        initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>
        <button type="button" onClick={onClose} className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-lg hover:bg-white/10" aria-label="Хаах"><X className="h-5 w-5" /></button>
        {me?.user ? <Profile onClose={onClose} /> : <AuthForm onDone={onClose} />}
      </motion.div>
    </>
  );
}

function AuthForm({ onDone }: { onDone: () => void }) {
  const { refreshMe, countLocally, prefs, showToast } = useStore();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [consent, setConsent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setMsg(""); setErrors({});
    setBusy(true);
    try {
      const body = mode === "login" ? { email, password } : { name, email, password, consent, area: prefs.area || undefined };
      const r = await fetch(`/api/auth/${mode}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const d = await r.json();
      if (!r.ok) { setMsg(d.error || "Алдаа гарлаа."); setErrors(d.errors || {}); return; }
      await refreshMe(); if (mode === "register") countLocally({ user: true });
      showToast(mode === "login" ? `Тавтай морил, ${d.user.name}` : "Бүртгэл үүслээ");
      onDone();
    } catch { setMsg("Сүлжээний алдаа."); } finally { setBusy(false); }
  }

  return (
    <div>
      <h2 className="font-display text-xl font-semibold">{mode === "login" ? "Нэвтрэх" : "Бүртгүүлэх"}</h2>
      <p className="mt-1 text-sm text-muted">Бүртгэлтэй бол AI-д тавьсан асуулт, мэдээлсэн асуудлаа аль ч төхөөрөмжөөс харна.</p>
      <div className="mt-4 flex gap-1 rounded-xl border border-line p-1" role="tablist">
        {(["login", "register"] as const).map((m) => (
          <button key={m} type="button" role="tab" aria-selected={mode === m} onClick={() => { setMode(m); setMsg(""); setErrors({}); }}
            className={cn("flex-1 rounded-lg py-2 text-sm font-semibold", mode === m ? "bg-cyan/15 text-cyan" : "text-muted")}>{m === "login" ? "Нэвтрэх" : "Бүртгүүлэх"}</button>
        ))}
      </div>
      <form onSubmit={submit} noValidate className="mt-4 grid gap-3">
        {mode === "register" && (
          <Field label="Нэр" htmlFor="a-name"><input id="a-name" className={inputCls} value={name} maxLength={60} autoComplete="name" onChange={(e) => setName(e.target.value)} />{errors.name && <p className="text-xs text-alert">{errors.name}</p>}</Field>
        )}
        <Field label="Имэйл" htmlFor="a-email"><input id="a-email" type="email" className={inputCls} value={email} autoComplete="email" onChange={(e) => setEmail(e.target.value)} />{errors.email && <p className="text-xs text-alert">{errors.email}</p>}</Field>
        <Field label="Нууц үг" htmlFor="a-pass"><input id="a-pass" type="password" className={inputCls} value={password} autoComplete={mode === "login" ? "current-password" : "new-password"} onChange={(e) => setPassword(e.target.value)} />
          {mode === "register" && <p className="text-xs text-muted">8-аас дээш тэмдэгт</p>}{errors.password && <p className="text-xs text-alert">{errors.password}</p>}</Field>
        {mode === "register" && (
          <label className="flex cursor-pointer items-start gap-2 text-xs text-muted">
            <input type="checkbox" className="mt-0.5 h-4 w-4 accent-[#00e5ff]" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
            <span>Миний нэр, имэйл, AI-д тавьсан асуулт, мэдээлсэн асуудал SMART ORKHON-ий санд хадгалагдаж, нэргүйгээр статистикт ашиглагдахыг зөвшөөрч байна. Бүртгэлээ хүссэн үедээ устгуулах боломжтой.</span>
          </label>
        )}
        {errors.consent && <p className="text-xs text-alert">{errors.consent}</p>}
        {msg && <p className="text-sm text-alert" role="alert">{msg}</p>}
        <Button type="submit" disabled={busy}>{busy ? "Түр хүлээнэ үү…" : mode === "login" ? "Нэвтрэх" : "Бүртгүүлэх"}</Button>
      </form>
    </div>
  );
}

function Profile({ onClose }: { onClose: () => void }) {
  const { me, logout, refreshMe, showToast } = useStore();
  const u = me!.user!;
  return (
    <div>
      <div className="flex items-center gap-3 pr-10">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-cyan/15 font-display text-xl font-semibold text-cyan"><User className="h-6 w-6" /></span>
        <div className="min-w-0"><p className="truncate font-semibold">{u.name}</p><p className="truncate text-xs text-muted">{u.email}</p></div>
      </div>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {u.role === "admin" && <Badge className="border-emerald/40 bg-emerald/10 text-emerald"><ShieldCheck className="h-3 w-3" />Админ</Badge>}
        <Badge className="border-line text-muted">Бүртгүүлсэн {fmtDate(u.createdAt)}</Badge>
      </div>

      <div className="mt-5 flex items-center justify-between"><h3 className="flex items-center gap-2 text-sm font-bold"><MessageSquare className="h-4 w-4 text-cyan" />AI-д тавьсан асуултууд</h3>
        {!!me?.questions?.length && (
          <button type="button" className="flex items-center gap-1 text-xs text-muted hover:text-alert"
            onClick={async () => { await fetch("/api/me", { method: "DELETE" }); await refreshMe(); showToast("Асуултын түүх устгагдлаа"); }}><Trash2 className="h-3.5 w-3.5" />Түүх устгах</button>
        )}</div>
      {me?.questions?.length ? (
        <ul className="mt-2 max-h-52 space-y-1.5 overflow-y-auto">
          {me.questions.map((q, i) => <li key={i} className="rounded-lg border border-line px-3 py-2 text-sm"><p>{q.question}</p><p className="mt-0.5 text-[12.5px] text-muted">{fmtDate(q.at, true)} · {q.mode === "gemini" ? "Gemini" : q.mode === "live" ? "Шууд мэдээлэл" : "Демо"}</p></li>)}
        </ul>
      ) : <p className="mt-2 text-sm text-muted">Одоогоор асуулт алга.</p>}

      <h3 className="mt-5 text-sm font-bold">Миний мэдээлсэн асуудал</h3>
      {me?.reports?.length ? (
        <ul className="mt-2 space-y-1.5">
          {me.reports.map((r) => (
            <li key={r.tracking} className="flex items-center gap-2 rounded-lg border border-line px-3 py-2 text-sm">
              <span className="min-w-0 flex-1"><span className="block truncate font-semibold">{r.title}</span><span className="text-[12.5px] text-muted">{r.tracking} · {ISSUE_CAT[r.category as IssueCategory] ?? r.category}</span></span>
              <Badge className={STATUS[r.status as IssueStatus]?.cls}>{STATUS[r.status as IssueStatus]?.label ?? r.status}</Badge>
            </li>
          ))}
        </ul>
      ) : <p className="mt-2 text-sm text-muted">Одоогоор мэдээлэл алга.</p>}

      <Button className="mt-6 w-full" variant="ghost" onClick={async () => { await logout(); showToast("Гарлаа"); onClose(); }}><LogOut className="h-4 w-4" />Гарах</Button>
    </div>
  );
}
