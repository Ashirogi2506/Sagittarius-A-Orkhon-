import { collectAnnouncements } from "@/lib/integrations";
import { all } from "@/lib/server/db";
import { clientKey, rateLimit } from "@/lib/server/guard";

// Real platform statistics from the database. Nothing here is sample data; an empty table
// simply returns zeros / empty lists. Live traffic is not here: the page reads /api/traffic.
//
// Kept cheap for the free database tier: totals come from the `counters` table, reports are
// read in one pass, and the whole answer is cached for 5 minutes (in memory and on the CDN).
const TTL_MS = 5 * 60_000;
const daysAgo = (n: number) => new Date(Date.now() - n * 864e5).toISOString();
const g = globalThis as unknown as { __soStats?: { at: number; body: unknown } };

async function compute() {
  const [counters, reports, questionsByDay, { items }] = await Promise.all([
    all<{ key: string; n: number }>("SELECT key, n FROM counters"),
    all<{ status: string; category: string; area: string; created_at: string }>("SELECT status, category, area, created_at FROM reports"),
    all<{ k: string; n: number }>(
      "SELECT date(created_at, '+8 hours') AS k, COUNT(*) AS n FROM chat_logs WHERE created_at >= ? GROUP BY k ORDER BY k", daysAgo(7)),
    collectAnnouncements(),
  ]);
  const total = (key: string) => counters.find((c) => c.key === key)?.n ?? 0;

  const tally = (keyOf: (r: (typeof reports)[number]) => string) => {
    const m = new Map<string, number>();
    for (const r of reports) { const k = keyOf(r); m.set(k, (m.get(k) || 0) + 1); }
    return [...m].map(([k, n]) => ({ k, n })).sort((a, b) => b.n - a.n);
  };
  const ubMonth = (iso: string) => new Date(new Date(iso).getTime() + 8 * 3600_000).toISOString().slice(0, 7);
  const since = daysAgo(186);
  const months = new Map<string, { n: number; resolved: number }>();
  for (const r of reports) {
    if (r.created_at < since) continue;
    const k = ubMonth(r.created_at);
    const m = months.get(k) ?? { n: 0, resolved: 0 };
    m.n++; if (r.status === "resolved") m.resolved++;
    months.set(k, m);
  }
  const byStatus = tally((r) => r.status);

  return {
    generatedAt: new Date().toISOString(),
    reports: {
      total: reports.length,
      resolved: byStatus.find((s) => s.k === "resolved")?.n ?? 0,
      byStatus,
      byCategory: tally((r) => r.category),
      byArea: tally((r) => r.area.split(",")[0].replace(/^.*·\s*/, "").trim()).slice(0, 8),
      byMonth: [...months].sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => ({ k, ...v })),
    },
    users: total("users"),
    questions: { total: total("questions"), byDay: questionsByDay },
    announcements: {
      verified: items.filter((a) => a.verification === "verified-note").length,
      demo: items.filter((a) => a.verification === "demo").length,
    },
  };
}

export async function GET(req: Request) {
  const rl = rateLimit("stats:" + clientKey(req), 30, 60_000);
  if (!rl.ok) return Response.json({ error: "Хэт олон хүсэлт." }, { status: 429 });
  if (!g.__soStats || Date.now() - g.__soStats.at > TTL_MS) g.__soStats = { at: Date.now(), body: await compute() };
  return Response.json(g.__soStats.body, {
    headers: { "Cache-Control": "public, max-age=0, s-maxage=300, stale-while-revalidate=60" },
  });
}
