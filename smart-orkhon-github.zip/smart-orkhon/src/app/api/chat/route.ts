import { buildContext, SYSTEM_PROMPT } from "@/lib/server/knowledge";
import { demoAnswer } from "@/lib/server/demoBot";
import { isTrafficQuestion, trafficAnswer } from "@/lib/integrations/traffic";
import { currentUser } from "@/lib/server/auth";
import { batch, bump, nowIso } from "@/lib/server/db";
import { callGemini, cleanText, clientKey, geminiErrorMessage, rateLimit, scrubPersonal } from "@/lib/server/guard";

export async function POST(req: Request) {
  const rl = rateLimit("chat:" + clientKey(req), 12, 60_000);
  if (!rl.ok) return Response.json({ error: `Хэт олон хүсэлт илгээлээ. ${rl.retryAfter} секундын дараа дахин оролдоно уу.` }, { status: 429 });

  let body: unknown;
  try { body = await req.json(); } catch { return Response.json({ error: "Хүсэлт буруу байна." }, { status: 400 }); }
  const b = body as { messages?: unknown; area?: unknown };
  if (!Array.isArray(b.messages) || b.messages.length === 0 || b.messages.length > 20) {
    return Response.json({ error: "Мессеж буруу байна." }, { status: 400 });
  }
  const msgs: { role: "user" | "model"; text: string }[] = [];
  for (const m of b.messages.slice(-10)) {
    const mm = m as { role?: unknown; text?: unknown };
    const text = cleanText(mm.text, 1200);
    if (!text || (mm.role !== "user" && mm.role !== "assistant")) return Response.json({ error: "Мессеж хэт урт эсвэл хоосон байна (1200 тэмдэгтээс бага)." }, { status: 400 });
    msgs.push({ role: mm.role === "user" ? "user" : "model", text: mm.role === "user" ? scrubPersonal(text) : text });
  }
  if (msgs[msgs.length - 1].role !== "user") return Response.json({ error: "Сүүлийн мессеж хэрэглэгчийнх байх ёстой." }, { status: 400 });
  const area = cleanText(b.area, 60) || undefined;

  const { text: ctx, anns, traffic } = await buildContext();
  const question = msgs[msgs.length - 1].text;
  // Without Gemini, traffic questions still get the real camera data (rule-based, labelled "live").
  const fallback = () => (isTrafficQuestion(question) ? { reply: trafficAnswer(traffic), mode: "live" } : { reply: demoAnswer(question, anns, area), mode: "demo" });

  // Save the question (personal numbers already scrubbed) for history and statistics. Never blocks the reply.
  const user = await currentUser().catch(() => null);
  const log = (mode: string, model?: string) => {
    return batch([
      { sql: "INSERT INTO chat_logs (user_id, question, mode, model, area, created_at) VALUES (?, ?, ?, ?, ?, ?)", args: [user?.id ?? null, question, mode, model ?? null, area ?? null, nowIso()] },
      bump("questions"),
    ]).catch((err) => console.error("[chat] log failed:", err instanceof Error ? err.message : err));
  };

  if (!process.env.GEMINI_API_KEY) { const f = fallback(); await log(f.mode); return Response.json(f); }
  try {
    const system = `${SYSTEM_PROMPT}\n\nХэрэглэгчийн сонгосон байршил: ${area || user?.area || "сонгоогүй"}.\n\nКОНТЕКСТ:\n${ctx}`;
    const { text: reply, model } = await callGemini(system, msgs);
    await log("gemini", model);
    return Response.json({ reply, mode: "gemini", model });
  } catch (e) {
    const code = e instanceof Error ? e.message : "ERR";
    const f = fallback(); await log(f.mode);
    return Response.json({ ...f, warning: geminiErrorMessage(code) });
  }
}
