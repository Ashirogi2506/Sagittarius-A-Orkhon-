import { currentUser } from "@/lib/server/auth";
import { nowIso, run } from "@/lib/server/db";
import { listGarbage, WEEKDAYS } from "@/lib/server/garbage";
import { cleanText } from "@/lib/server/guard";

export async function GET() {
  return Response.json({ items: await listGarbage() });
}

const TIME = /^([01]\d|2[0-3]):[0-5]\d$/;

// Only admins (ADMIN_EMAILS in .env.local) can add or remove schedule entries.
export async function POST(req: Request) {
  const user = await currentUser();
  if (user?.role !== "admin") return Response.json({ error: "Зөвхөн админ хуваарь оруулна." }, { status: 403 });
  let b: Record<string, unknown>;
  try { b = await req.json(); } catch { return Response.json({ error: "Хүсэлт буруу байна." }, { status: 400 }); }
  const sum = cleanText(b.sum, 60);
  const bag = cleanText(b.bag, 60) || null;
  const area = cleanText(b.area, 80) || null;
  const days = Array.isArray(b.days) ? WEEKDAYS.filter((d) => (b.days as unknown[]).includes(d)) : [];
  const timeFrom = typeof b.timeFrom === "string" && TIME.test(b.timeFrom) ? b.timeFrom : null;
  const timeTo = typeof b.timeTo === "string" && TIME.test(b.timeTo) ? b.timeTo : null;
  const note = cleanText(b.note, 300) || null;
  const source = cleanText(b.source, 300) || null;
  if (!sum || (!bag && !area) || !days.length) return Response.json({ error: "Сум, баг эсвэл хороолол, гаригаа заавал оруулна." }, { status: 400 });
  if (source && !/^https?:\/\//.test(source) && source.length < 3) return Response.json({ error: "Эх сурвалж буруу." }, { status: 400 });
  await run("INSERT INTO garbage_schedule (sum, bag, area, days, time_from, time_to, note, source, created_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    sum, bag, area, days.join(","), timeFrom, timeTo, note, source, user.id, nowIso());
  return Response.json({ items: await listGarbage() });
}

export async function DELETE(req: Request) {
  const user = await currentUser();
  if (user?.role !== "admin") return Response.json({ error: "Зөвхөн админ устгана." }, { status: 403 });
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isInteger(id) || id <= 0) return Response.json({ error: "id буруу." }, { status: 400 });
  await run("DELETE FROM garbage_schedule WHERE id = ?", id);
  return Response.json({ items: await listGarbage() });
}
