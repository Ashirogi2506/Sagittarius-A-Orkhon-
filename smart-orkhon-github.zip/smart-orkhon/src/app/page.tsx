import { StoreProvider } from "@/lib/store";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { Announcements } from "@/components/Announcements";
import { ReportSection } from "@/components/ReportSection";
import { MapSection } from "@/components/MapSection";
import { GarbageSection } from "@/components/GarbageSection";
import { SolvedSection } from "@/components/SolvedSection";
import { Community } from "@/components/Community";
import { Analytics } from "@/components/Analytics";
import { Summarizer } from "@/components/Summarizer";
import { ChatWidget } from "@/components/ChatWidget";
import { About, Footer, Toast } from "@/components/About";
import { AlertBanner, AlertsSection } from "@/components/Alerts";
import { BusSection } from "@/components/BusSection";

export default function Home() {
  return (
    <StoreProvider>
      <a href="#notices" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[70] focus:rounded-lg focus:bg-cyan focus:px-4 focus:py-2 focus:text-navy">Мэдэгдэл рүү шилжих</a>
      <Header />
      <AlertBanner />
      <main>
        <Hero />
        <AlertsSection />
        <Announcements />
        <ReportSection />
        <MapSection />
        <BusSection />
        <GarbageSection />
        <SolvedSection />
        <Community />
        <Analytics />
        <Summarizer />
        <About />
      </main>
      <Footer />
      <ChatWidget />
      <Toast />
    </StoreProvider>
  );
}
