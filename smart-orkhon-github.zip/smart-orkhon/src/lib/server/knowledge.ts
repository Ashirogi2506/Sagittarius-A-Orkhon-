import { collectAnnouncements } from "../integrations";
import { DEMO_ISSUES } from "../data/places";
import { ANN_CAT, ISSUE_CAT, STATUS, VERIFY, fmtDate } from "../labels";
import type { Announcement } from "../types";
import { getTraffic, trafficContext, TRAFFIC_PAGE, type TrafficSnapshot } from "../integrations/traffic";
import { garbageContext } from "./garbage";
import { alertsContext, busContext } from "./alerts";
import { getWeather, weatherContext } from "../integrations/weather";

export const NO_INFO = "Одоогоор баталгаажсан мэдээлэл олдсонгүй.";

export function annLine(a: Announcement): string {
  const where = [a.location.sum, a.location.bag, a.location.area].filter(Boolean).join(", ") + (a.locationNote ? ` (${a.locationNote})` : "");
  const when = a.start ? `${fmtDate(a.start, true)}${a.end ? " – " + fmtDate(a.end, true) : ""}` : "цаг тодорхойгүй";
  return `[${VERIFY[a.verification].label}] ${a.organization}: ${a.title}. Ангилал: ${ANN_CAT[a.category].label}. Байршил: ${where}. Хугацаа: ${when}. Товч: ${a.summary} Эх сурвалж: ${a.sourceUrl}. Нийтэлсэн: ${fmtDate(a.publishedAt)}. Шалгасан: ${fmtDate(a.checkedAt, true)}.`;
}

export async function buildContext(): Promise<{ text: string; anns: Announcement[]; traffic: TrafficSnapshot }> {
  const [{ items }, traffic, garbage, alerts, bus, weather] = await Promise.all([
    collectAnnouncements(), getTraffic(),
    garbageContext().catch(() => "ХОГ АЧИЛТЫН ХУВААРЬ: одоогоор уншиж чадсангүй."),
    alertsContext().catch(() => "ШУУРХАЙ МЭДЭЭЛЭЛ: одоогоор уншиж чадсангүй."),
    busContext().catch(() => "АВТОБУСНЫ ЧИГЛЭЛ: одоогоор уншиж чадсангүй."),
    getWeather().then(weatherContext),
  ]);
  const issues = DEMO_ISSUES.map((i) => `[Жишээ] ${i.id} ${i.title} — ${ISSUE_CAT[i.category]}, ${i.area}, төлөв: ${STATUS[i.status].label}${i.action ? ", авсан арга хэмжээ: " + i.action : ""}${i.resolvedAt ? ", шийдсэн: " + fmtDate(i.resolvedAt) : ""}.`);
  const text = [
    alerts,
    "",
    "МЭДЭГДЛҮҮД:",
    ...items.map(annLine),
    "",
    trafficContext(traffic),
    "",
    garbage,
    "",
    bus,
    "",
    weather,
    "",
    "ИРГЭДИЙН АСУУДЛУУД (бүгд жишээ өгөгдөл):",
    ...issues,
    "",
    "АСУУДАЛ МЭДЭЭЛЭХ: сайтын «Асуудал мэдээлэх» хэсэгт гарчиг, ангилал, байршил, тайлбар, зураг оруулаад илгээнэ. Хяналтын дугаар өгнө. Мэдээлэл SMART ORKHON-ий санд хадгалагдах бөгөөд албан байгууллагад автоматаар илгээгдэхгүй.",
    "ЯАРАЛТАЙ УТАС: 101 гал, 102 цагдаа, 103 түргэн тусламж, 105 онцгой байдал, 11-11 санал гомдол.",
  ].join("\n");
  return { text, anns: items, traffic };
}

export const SYSTEM_PROMPT = `Чи бол "Орхон AI туслах". SMART ORKHON платформын иргэдэд туслах туслагч.
Дүрэм:
- Зөвхөн монгол кирилл үсгээр, энгийн, товч, найрсаг хариул.
- Зөвхөн доорх КОНТЕКСТ дэх мэдээлэлд тулгуурла. Албан ёсны мэдээлэл, огноо, цаг, байршлыг хэзээ ч зохиож болохгүй, таамаглаж болохгүй.
- Асуултад тохирох баталгаажсан мэдээлэл байхгүй бол яг ингэж эхэл: "${NO_INFO}" Дараа нь хаанаас шалгахыг (эх сурвалжийн холбоос) зөвлө.
- Мэдээлэл бүрийн шошгыг заавал хэл: "[Гараар шалгасан]" бол багийнхан албан ёсны сувгаас гараар шалгасан тэмдэглэл, "[Жишээ мэдээлэл]" бол жинхэнэ зар биш, үзүүлэх зорилготой жишээ.
- Хариултын төгсгөлд эх сурвалжийн холбоос, шалгасан огноог бич.
- Түгжрэл, замын ачааллын асуултад КОНТЕКСТ-ийн "ЗАМЫН АЧААЛАЛ (шууд)" хэсгийг ашигла: ачаалалтай цэгүүдийг нэр, түвшин, машины тоотой нь жагсааж, хэдэн цагийн байдлаар болохыг хэл. Ачаалалтай цэг байхгүй бол "одоогоор түгжрэлгүй" гэж хэл. Хуучирсан цэгийг одоогийн байдал гэж бүү хэл. Энэ бол камерын автомат тооллого, шошго нь "[Шууд мэдээлэл]". Хариултын төгсгөлд заавал "Шууд камер, газрын зураг: ${TRAFFIC_PAGE}" гэж бич.
- Хаалттай зам, зам засварын мэдээлэл КОНТЕКСТ-д байхгүй бол "${NO_INFO}" гэж эхэлж, ${TRAFFIC_PAGE} хаягаас шалгахыг зөвлө.
- Ус, цахилгаан, дулаан тасралт, онцгой байдлын асуултад эхлээд "ШУУРХАЙ МЭДЭЭЛЭЛ" хэсгийг шалга.
- Автобусны чиглэл, зогсоол, үнийг зөвхөн "АВТОБУСНЫ ЧИГЛЭЛ" хэсгээс хэл. "Хаанаас хаашаа ямар автобус явах вэ" гэвэл тэр хоёр зогсоолыг дарааллаар нь агуулсан чиглэлийг ол. Байхгүй бол зохиохгүй.
- Цаг агаарын асуултад "ЦАГ АГААР" хэсгийг ашиглаж, энэ нь загварын урьдчилсан мэдээ гэдгийг дурд.
- Хувийн мэдээлэл (утас, регистр, хаяг) асуухгүй, хадгалахгүй.
- Яаралтай аюулын үед 101, 102, 103, 105 руу залгахыг зөвлө.`;
