// Live road load from Орхон аймгийн ТКХДТ (dedtuv.erdenet.mn) camera detections.
// Public JSON used by their own /live page. Fetched server-side only and cached briefly.
import { CAMERAS } from "../data/cameras";

export const TRAFFIC_PAGE = "https://dedtuv.erdenet.mn/live";
const TRAFFIC_API = "https://dedtuv.erdenet.mn/api/traffic";
const CACHE_MS = 60_000;
const STALE_MS = 30 * 60_000;

export interface TrafficSpot {
  id: string;
  name: string;
  lat: number;
  lng: number;
  vehicles: number;
  level: string; // LOW | MEDIUM | HIGH | ... as reported by the source
  detectedAt: string;
  stale: boolean;
}

export interface TrafficSnapshot {
  ok: boolean;
  spots: TrafficSpot[];
  fetchedAt: string;
  source: string;
}

export const LEVEL_LABEL: Record<string, string> = {
  LOW: "Ачаалалгүй",
  MEDIUM: "Дунд зэргийн ачаалалтай",
  HIGH: "Ачаалал ихтэй",
  VERY_HIGH: "Маш их ачаалалтай",
  JAM: "Түгжрэлтэй",
};
const LEVEL_RANK: Record<string, number> = { LOW: 0, MEDIUM: 1, HIGH: 2, VERY_HIGH: 3, JAM: 3 };
export const levelLabel = (l: string) => LEVEL_LABEL[l] ?? l;
export const levelRank = (l: string) => LEVEL_RANK[l] ?? 1;

let cache: { at: number; snap: TrafficSnapshot } | null = null;

function parse(raw: unknown, now: number): TrafficSpot[] {
  if (!Array.isArray(raw)) throw new Error("BAD_SHAPE");
  const out: TrafficSpot[] = [];
  for (const r of raw.slice(0, 200)) {
    const o = r as Record<string, unknown>;
    if (typeof o.name !== "string" || typeof o.lat !== "number" || typeof o.lng !== "number") continue;
    const detectedAt = typeof o.detectedAt === "string" ? o.detectedAt : "";
    const t = Date.parse(detectedAt);
    out.push({
      id: typeof o.id === "string" ? o.id.slice(0, 64) : o.name.trim(),
      name: o.name.trim().slice(0, 80),
      lat: o.lat,
      lng: o.lng,
      vehicles: typeof o.vehicleCount === "number" ? o.vehicleCount : 0,
      level: typeof o.loadLevel === "string" ? o.loadLevel.toUpperCase().slice(0, 20) : "UNKNOWN",
      detectedAt,
      stale: !Number.isFinite(t) || now - t > STALE_MS,
    });
  }
  return out;
}

export async function getTraffic(): Promise<TrafficSnapshot> {
  const now = Date.now();
  if (cache && now - cache.at < CACHE_MS) return cache.snap;
  try {
    const r = await fetch(TRAFFIC_API, { cache: "no-store", headers: { Accept: "application/json" }, signal: AbortSignal.timeout(8_000) });
    if (!r.ok) throw new Error("HTTP_" + r.status);
    const spots = parse(await r.json(), now);
    const snap = { ok: true, spots, fetchedAt: new Date(now).toISOString(), source: TRAFFIC_PAGE };
    cache = { at: now, snap };
    return snap;
  } catch {
    // Keep the last good snapshot for a few minutes rather than nothing; otherwise report failure.
    if (cache && now - cache.at < 5 * 60_000) return cache.snap;
    return { ok: false, spots: [], fetchedAt: new Date(now).toISOString(), source: TRAFFIC_PAGE };
  }
}

const hm = (iso: string) => new Date(iso).toLocaleTimeString("mn-MN", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "Asia/Ulaanbaatar" });

/** Text block for the AI context. Only fresh readings count as current. */
export function trafficContext(s: TrafficSnapshot): string {
  if (!s.ok) return `ЗАМЫН АЧААЛАЛ (шууд): эх сурвалжаас одоогоор татаж чадсангүй. Шууд харах: ${TRAFFIC_PAGE}`;
  const fresh = s.spots.filter((x) => !x.stale).sort((a, b) => levelRank(b.level) - levelRank(a.level) || b.vehicles - a.vehicles);
  const stale = s.spots.filter((x) => x.stale);
  const busy = fresh.filter((x) => levelRank(x.level) >= 1);
  return [
    `ЗАМЫН АЧААЛАЛ (шууд, Орхон аймгийн ТКХДТ-ийн камерын автомат тооллого, татсан: ${hm(s.fetchedAt)}, эх сурвалж: ${s.source}):`,
    busy.length ? `Ачаалалтай цэгүүд: ${busy.map((x) => `${x.name} — ${levelLabel(x.level)}, ${x.vehicles} машин (${hm(x.detectedAt)})`).join("; ")}.` : "Ачаалалтай цэг одоогоор бүртгэгдээгүй.",
    `Ачаалалгүй цэгүүд: ${fresh.filter((x) => levelRank(x.level) < 1).map((x) => `${x.name} (${x.vehicles})`).join(", ") || "байхгүй"}.`,
    stale.length ? `Хуучирсан (30 минутаас дээш шинэчлэгдээгүй, одоогийн байдал гэж бүү хэл): ${stale.map((x) => x.name).join(", ")}.` : "",
    `Машин тоолдоггүй камерууд (ачааллыг нь мэдэхгүй, таамаглаж болохгүй): ${CAMERAS.filter((c) => !s.spots.some((x) => x.id === c.id)).map((c) => c.name).join(", ") || "байхгүй"}.`,
    "Эдгээр камер, цэгээс бусад замын ачааллын мэдээлэл байхгүй.",
  ].filter(Boolean).join("\n");
}

/** Deterministic answer used in demo mode or when Gemini fails. Real data, no AI. */
export function trafficAnswer(s: TrafficSnapshot): string {
  if (!s.ok) return `Замын ачааллын шууд мэдээллийг одоогоор татаж чадсангүй.\nШууд камер, газрын зургаар энд харна уу: ${TRAFFIC_PAGE}`;
  const fresh = s.spots.filter((x) => !x.stale).sort((a, b) => levelRank(b.level) - levelRank(a.level) || b.vehicles - a.vehicles);
  const busy = fresh.filter((x) => levelRank(x.level) >= 1);
  const head = busy.length
    ? "Одоогоор ачаалалтай цэгүүд:\n" + busy.map((x) => `• ${x.name} — ${levelLabel(x.level)}, ${x.vehicles} машин`).join("\n")
    : `Одоогоор камертай ${fresh.length} цэгийн аль нь ч түгжрэлгүй, ачаалал бага байна.`;
  const calm = busy.length ? `\n\nБусад ${fresh.length - busy.length} цэг ачаалалгүй.` : "";
  return `${head}${calm}\n\nМэдээлэл: Орхон аймгийн ТКХДТ-ийн камерын автомат тооллого, ${hm(s.fetchedAt)}-ийн байдлаар.\nШууд камер, газрын зураг: ${TRAFFIC_PAGE}`;
}

export const isTrafficQuestion = (q: string) => /түгжр|ачаалал|замын хөдөлгөөн|бөглөр|машин ихтэй|зам хаагд|хаалттай зам|камер/i.test(q);
